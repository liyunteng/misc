The CIR driver supports Nuvoton NCT6775/NCT6776/NCT6106/NCT6779.

1. Compile and install driver

For compiling the driver, use following command:

# make

Then you can get the driver nuvoton-cir.ko      

Please replace the old driver under "/lib/modules/[your kernel version here]/kernel/drivers/media/rc/"

Then use following command to update database:

# depmod -a

And reboot. (It is recommended)


2. Load driver and use it

Following command can load the driver:

# modprobe nuvoton-cir 

It should not return any error message if it is loaded successfully.

You can also check whether the driver is loaded or not by following command:

# lsmod | grep nuvoton

If the driver is loaded, you can see the driver's module name appeared in the returned information.

Now you can test your remote control by pressing some keys.

You also can install the tool "ir-keytable" and use following command to test key press:

# ir-keytable -t

For more information about the usage of ir-keytable, please search the command on the Internet.

