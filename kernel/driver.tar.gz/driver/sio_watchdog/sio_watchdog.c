#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/io.h>
#include <linux/fs.h>
#include <linux/miscdevice.h>
#include <linux/platform_device.h>
#include <linux/ioport.h>
#include <linux/jiffies.h>
#include <linux/slab.h>
#include <linux/sysfs.h>
#include <linux/device.h>
//#include "sio_watchdog.h"

#define VERSION_STRING	"1.0"

#define EFER_REG 		0x2e
#define EFIR_REG 		EFER_REG
#define EFDR_REG 		(EFIR_REG+1)


#define SIO_WDT_DEV_NAME			"sio_wdt"
#define SIO_WDT_DEF_TIME			255			/*Default time-out: 255s*/
#define SIO_WDT_MAX_TIME			255
#define SIO_WDT_LOGIC_DEV_ID		0x08
#define SIO_WDT_2_LOGIC_DEV_ID	0x0D

#define SIO_ACCESS_DELAY			10			/* 10ms*/


#define SIO_WDT_ENABLE				0x56
#define SIO_WDT_DISABLE			0x57
#define SIO_WDT_SET_TIME			0x58
#define SIO_WDT_FEED				0x59

#define SIO_WDT_2_ENABLE			0x5A
#define SIO_WDT_2_DISABLE			0x5B


#define SIO_WDT_DEV_ATTR(_name, _mode, _show, _store, _index)	\
	{ .dev_attr = __ATTR(_name, _mode, _show, _store),	\
	  .index = _index }

static unsigned char prev_load_time = 0;

static int sio_watchdog_def_time = SIO_WDT_DEF_TIME;
module_param( sio_watchdog_def_time, int, 0 );
MODULE_PARM_DESC( sio_watchdog_def_time, "Default watchdog time-out value(255)");

struct sio_wdt_device_attribute
{
	struct device_attribute dev_attr;
	int index;
};


struct sio_watchdog_dev
{
	struct platform_device *sio_wdt_platform_dev;
	unsigned int open_counts;	
};
struct sio_watchdog_dev *sio_wdt_dev;

static int sio_watchdog_open ( struct inode *inode, struct file *filp )
{
	if ( sio_wdt_dev->open_counts > 0 )
	{
		printk ( "Opened by other user.\n" );
		return -EBUSY;
	}
	
	return 0;
}

static int sio_watchdog_close ( struct inode *inode, struct file *filp )
{
	sio_wdt_dev->open_counts = 0;
	return 0;
}

static long sio_watchdog_ioctl ( struct file *filp, unsigned int cmd, unsigned long arg )
{
	
	unsigned char temp;
	unsigned long jiffies_expires;
	unsigned char retry_times = 10;
	
	struct resource *sio_access_io_res;

retry:
	/*
	 * In smbus-power module, EFER_REG was also used do access the sio
	 * so here request_regsion was called to protect the unique access to sio.
	*/
	sio_access_io_res = request_region ( EFER_REG, 2, SIO_WDT_DEV_NAME );
	if ( NULL == sio_access_io_res )
	{
		jiffies_expires = jiffies + msecs_to_jiffies ( SIO_ACCESS_DELAY );
		while (  jiffies < jiffies_expires )
		{
			cpu_relax();
		}

		if ( retry_times-- )
		{
			goto retry;
		}
		else
		{
			printk ( "Failed to request io region for sio.\n" );
			return -EBUSY;
		}
		
	}

	switch ( cmd )
	{
		case SIO_WDT_2_ENABLE:
			/* Enter config mode */
			outb ( 0x87, EFER_REG );
			outb ( 0x87, EFER_REG );
			outb ( 0x07, EFIR_REG );
			outb ( SIO_WDT_2_LOGIC_DEV_ID, EFDR_REG );

			/* Set the time */
			outb ( 0xE0, EFIR_REG );
			outb ( 1, EFDR_REG);

			/* Clear the status */
			outb ( 0xE4, EFIR_REG );
			outb ( 0x00, EFDR_REG );

			/* Start the timer */
			outb ( 0xE3, EFIR_REG );
			outb ( 1, EFDR_REG );

			/* Exit config mode */
			outb ( 0xAA, EFER_REG );
			
			break;
		case SIO_WDT_2_DISABLE:
			/* Enter config mode */
			outb ( 0x87, EFER_REG );
			outb ( 0x87, EFER_REG );
			outb ( 0x07, EFIR_REG );
			outb ( SIO_WDT_2_LOGIC_DEV_ID, EFDR_REG );

			/* Stop the timer */
			outb ( 0xE3, EFIR_REG );
			outb ( 0, EFDR_REG );

			/* Exit config mode */
			outb ( 0xAA, EFER_REG );
			break;
		case SIO_WDT_ENABLE:
			/* Enter config mode */
			outb ( 0x87, EFER_REG );
			outb ( 0x87, EFER_REG );
			outb ( 0x07, EFIR_REG );
			outb ( SIO_WDT_LOGIC_DEV_ID, EFDR_REG );
			
			/* Enable wdt */
			outb ( 0x30, EFIR_REG );
			temp = inb ( EFDR_REG );
			outb ( temp | 0x01, EFDR_REG );

			/* Set watch dog timer in second mode */
			outb ( EFIR_REG, 0xF0 );
			temp = inb ( EFDR_REG );
			temp = temp & 0x07;
			temp = temp | 0x02;
			outb ( temp, EFDR_REG );

			/* Clear flag */
			outb ( 0xF2, EFIR_REG );
			outb ( 0x0, EFDR_REG );

			/* Set Default time */
			outb ( 0xF1, EFIR_REG );
			if ( prev_load_time == 0 )
			{
				prev_load_time = sio_watchdog_def_time;
			}
			outb ( prev_load_time, EFDR_REG );

			/* Exit config mode */
			outb ( 0xAA, EFER_REG );
			
			break;
		case SIO_WDT_DISABLE:
			/* Enter config mode */
			outb ( 0x87, EFER_REG );
			outb ( 0x87, EFER_REG );
			outb ( 0x07, EFIR_REG );
			outb ( SIO_WDT_LOGIC_DEV_ID, EFDR_REG );
			
			/* Disable wdt */
			outb ( 0x30, EFIR_REG );
			temp = inb ( EFDR_REG );
			temp &= 0xFE;
			outb ( temp, EFDR_REG );

			/* Clear flag */
			outb ( 0xF2, EFIR_REG );
			outb ( 0x0, EFDR_REG );

			/* Write zero to disable the timer */
			outb ( 0xF1, EFIR_REG );
			outb ( 0x00, EFDR_REG );

			/* Exit config mode */
			outb ( 0xAA, EFER_REG );
			break;
		case SIO_WDT_SET_TIME:
			if ( arg <= SIO_WDT_MAX_TIME )
			{
				prev_load_time = arg & 0xFF;
			}
			else
			{
				printk ( "The arg is too large for the wdt counter register.\n" );
			}
			break;
		case SIO_WDT_FEED:
			/* Enter config mode */
			outb ( 0x87, EFER_REG );
			outb ( 0x87, EFER_REG );
			outb ( 0x07, EFIR_REG );
			outb ( SIO_WDT_LOGIC_DEV_ID, EFDR_REG );


			outb ( 0x30, EFIR_REG );
			temp = inb ( EFDR_REG );

			if (( temp & 0x01 ) == 0 )		/*watchdog was disable*/
			{
				release_region ( EFER_REG, 2 );
				outb ( 0xAA, EFER_REG );
				return -EAGAIN;
			}

			/* Set Default time */
			outb ( 0xF1, EFIR_REG );
			outb ( prev_load_time, EFDR_REG );

			/* Exit config mode */
			outb ( 0xAA, EFER_REG );
			break;
		default:
			break;
	}

	release_region ( EFER_REG, 2 );

	return 0;
}

static struct file_operations sio_watchdog_fops = 
{
	.open 			= sio_watchdog_open,
	.unlocked_ioctl	= sio_watchdog_ioctl,
	.release			= sio_watchdog_close,
};

static struct miscdevice sio_watchdog_miscdev =
{
	.name	= SIO_WDT_DEV_NAME,
	.minor	= MISC_DYNAMIC_MINOR,
	.fops	= &sio_watchdog_fops,
};

static ssize_t sio_wdt_enable_show ( struct device *dev, 
									struct device_attribute *attr,
									char *buf )
{
	unsigned char temp;
	unsigned long jiffies_expires;
	unsigned char retry_times = 10;
	
	struct resource *sio_access_io_res;

retry:
	/*
	 * In smbus-power module, EFER_REG was also used do access the sio
	 * so here request_regsion was called to protect the unique access to sio.
	*/
	sio_access_io_res = request_region ( EFER_REG, 2, SIO_WDT_DEV_NAME );
	if ( NULL == sio_access_io_res )
	{
		jiffies_expires = jiffies + msecs_to_jiffies ( SIO_ACCESS_DELAY );
		while (  jiffies < jiffies_expires )
		{
			cpu_relax();
		}

		if ( retry_times-- )
		{
			goto retry;
		}
		else
		{
			printk ( "Failed to request io region for sio.\n" );
			return -EBUSY;
		}
		
	}
	/* Enter config mode */
	outb ( 0x87, EFER_REG );
	outb ( 0x87, EFER_REG );
	outb ( 0x07, EFIR_REG );
	outb ( SIO_WDT_LOGIC_DEV_ID, EFDR_REG );
	
	/* Enable wdt */
	outb ( 0x30, EFIR_REG );
	temp = inb ( EFDR_REG );

	/* Exit config mode */
	outb ( 0xAA, EFER_REG );

	release_region ( EFER_REG, 2 );

	if ( temp & 0x01 )
	{
		return sprintf ( buf, "sio watch dog was enabled.\n" );
	}
	else
	{
		return sprintf ( buf, "sio watch dog was disabled.\n");
	}
	
}	

static ssize_t sio_wdt_enable_store ( struct device *dev,
									struct device_attribute *attr,
									const char *buf, 
									size_t count )
{
	unsigned long val = simple_strtoul ( buf, NULL, 10 );

	unsigned char temp;
	unsigned long jiffies_expires;
	unsigned char retry_times = 10;
	
	struct resource *sio_access_io_res;

retry:
	/*
	 * In smbus-power module, EFER_REG was also used do access the sio
	 * so here request_regsion was called to protect the unique access to sio.
	*/
	sio_access_io_res = request_region ( EFER_REG, 2, SIO_WDT_DEV_NAME );
	if ( NULL == sio_access_io_res )
	{
		jiffies_expires = jiffies + msecs_to_jiffies ( SIO_ACCESS_DELAY );
		while (  jiffies < jiffies_expires )
		{
			cpu_relax();
		}

		if ( retry_times-- )
		{
			goto retry;
		}
		else
		{
			printk ( "Failed to request io region for sio.\n" );
			return -EBUSY;
		}
		
	}
	/* Enter config mode */
	outb ( 0x87, EFER_REG );
	outb ( 0x87, EFER_REG );
	outb ( 0x07, EFIR_REG );
	outb ( SIO_WDT_LOGIC_DEV_ID, EFDR_REG );
	
	if ( val == 0 )
	{
		/*Disable the wdt*/
		outb ( 0x30, EFIR_REG );
		temp = inb ( EFDR_REG );
		temp &= 0xFE;
		outb ( temp, EFDR_REG );

		/* Clear flag */
		outb ( 0xF2, EFIR_REG );
		outb ( 0x0, EFDR_REG );

		/* Write zero to disable the timer */
		outb ( 0xF1, EFIR_REG );
		outb ( 0x00, EFDR_REG );
	}
	else if ( val == 1 )
	{
		/*Enable the wdt*/
		outb ( 0x30, EFIR_REG );
		temp = inb ( EFDR_REG );
		outb ( temp | 0x01, EFDR_REG );

		/* Set watch dog timer in second mode */
		outb ( EFIR_REG, 0xF0 );
		temp = inb ( EFDR_REG );
		temp = temp & 0x07;
		temp = temp | 0x02;
		outb ( temp, EFDR_REG );

		/* Clear flag */
		outb ( 0xF2, EFIR_REG );
		outb ( 0x0, EFDR_REG );

		/* Set Default time */
		outb ( 0xF1, EFIR_REG );
		if ( prev_load_time == 0 )
		{
			prev_load_time = sio_watchdog_def_time;
		}
		outb ( prev_load_time, EFDR_REG );
		
	}

	/* Exit config mode */
	outb ( 0xAA, EFER_REG );

	release_region ( EFER_REG, 2 );
	return count;
}


ssize_t sio_wdt_count_store ( struct device *dev,
							struct device_attribute *attr,
							const char *buf,
							size_t count )
{
	unsigned long val = simple_strtoul ( buf, NULL, 10 );

	unsigned char temp;
	unsigned long jiffies_expires;
	unsigned char retry_times = 10;
	
	struct resource *sio_access_io_res;

retry:
	/*
	 * In smbus-power module, EFER_REG was also used do access the sio
	 * so here request_regsion was called to protect the unique access to sio.
	*/
	sio_access_io_res = request_region ( EFER_REG, 2, SIO_WDT_DEV_NAME );
	if ( NULL == sio_access_io_res )
	{
		jiffies_expires = jiffies + msecs_to_jiffies ( SIO_ACCESS_DELAY );
		while (  jiffies < jiffies_expires )
		{
			cpu_relax();
		}

		if ( retry_times-- )
		{
			goto retry;
		}
		else
		{
			printk ( "Failed to request io region for sio.\n" );
			return -EBUSY;
		}
		
	}
	/* Enter config mode */
	outb ( 0x87, EFER_REG );
	outb ( 0x87, EFER_REG );
	outb ( 0x07, EFIR_REG );
	outb ( SIO_WDT_LOGIC_DEV_ID, EFDR_REG );

	outb ( 0x30, EFIR_REG );
	temp = inb ( EFDR_REG );

	if ((( temp & 0x01 ) == 0 ) || ( val > SIO_WDT_MAX_TIME ))
	{
		release_region ( EFER_REG, 2 );
		/* Exit config mode */
		outb ( 0xAA, EFER_REG );
		return count;
	}

	/* Set time */
	outb ( 0xF1, EFIR_REG );
	outb ( val & 0xFF, EFDR_REG );
	prev_load_time = val & 0xFF;

	/* Exit config mode */
	outb ( 0xAA, EFER_REG );

	release_region ( EFER_REG, 2 );
	
	return count;
}			

ssize_t sio_wdt_feed_store ( struct device *dev,
							struct device_attribute *attr,
							const char *buf,
							size_t count )
{
	unsigned long val = simple_strtoul ( buf, NULL, 10 );

	unsigned char temp;
	unsigned long jiffies_expires;
	unsigned char retry_times = 10;
	
	struct resource *sio_access_io_res;

retry:
	/*
	 * In smbus-power module, EFER_REG was also used do access the sio
	 * so here request_regsion was called to protect the unique access to sio.
	*/
	sio_access_io_res = request_region ( EFER_REG, 2, SIO_WDT_DEV_NAME );
	if ( NULL == sio_access_io_res )
	{
		jiffies_expires = jiffies + msecs_to_jiffies ( SIO_ACCESS_DELAY );
		while (  jiffies < jiffies_expires )
		{
			cpu_relax();
		}

		if ( retry_times-- )
		{
			goto retry;
		}
		else
		{
			printk ( "Failed to request io region for sio.\n" );
			return -EBUSY;
		}
		
	}
	
	if ( val == 0 )
	{
		release_region ( EFER_REG, 2 );
		return count;
	}

	/* Enter config mode */
	outb ( 0x87, EFER_REG );
	outb ( 0x87, EFER_REG );
	outb ( 0x07, EFIR_REG );
	outb ( SIO_WDT_LOGIC_DEV_ID, EFDR_REG );

	outb ( 0x30, EFIR_REG );
	temp = inb ( EFDR_REG );

	if (( temp & 0x01 ) == 0 )
	{
		release_region ( EFER_REG, 2 );
		outb ( 0xAA, EFER_REG );
		return count;
	}

	/* Set time */
	outb ( 0xF1, EFIR_REG );
	outb ( prev_load_time, EFDR_REG );

	/* Exit config mode */
	outb ( 0xAA, EFER_REG );

	release_region ( EFER_REG, 2 );

	return count;
}

static struct sio_wdt_device_attribute sio_wdt_dev_ctrl[] =
{
	SIO_WDT_DEV_ATTR ( sio_wdt_enable, S_IRUGO | S_IWUSR, 
							sio_wdt_enable_show, 
							sio_wdt_enable_store, 0 ),
	SIO_WDT_DEV_ATTR ( sio_wdt_count, S_IWUSR,
							NULL,
							sio_wdt_count_store, 1 ),
	SIO_WDT_DEV_ATTR ( sio_wdt_feed, S_IWUSR,
							NULL,
							sio_wdt_feed_store, 2 ),							
};

static int __init sio_watchdog_init ( void )
{
	int err;
	int i;
	unsigned char temp;

	sio_wdt_dev = kzalloc ( sizeof ( struct sio_watchdog_dev ), GFP_KERNEL );
	if ( sio_wdt_dev == NULL )
	{
		printk ( "Failed to malloc memory for sio_watchdog_dev.\n" );
		goto exit;
	}
	sio_wdt_dev->open_counts = 0;

	sio_wdt_dev->sio_wdt_platform_dev = platform_device_alloc ( "sio_watchdog", 0 );
	if ( !( sio_wdt_dev->sio_wdt_platform_dev  ))
	{
		printk ( "Failed to alloc platform device for sio watchdog.\n" );
		goto err0;
	}

	err = platform_device_add ( sio_wdt_dev->sio_wdt_platform_dev );
	if ( err )
	{
		printk( KERN_ERR "SIO watchdog device addition failed (%d)\n", err);
		goto err1;
	}

	err = misc_register ( &sio_watchdog_miscdev );
	if ( err )
	{
		kfree ( sio_wdt_dev );
		goto err1;
	}
	

	for ( i = 0; i < 3; i++ )
	{
		err = device_create_file( &(( sio_wdt_dev->sio_wdt_platform_dev)->dev ),  
										&( sio_wdt_dev_ctrl[i].dev_attr ));
		if ( err )
		{
			goto err2;
		}
		
	}

	/*
	 * In default state, the watchdog was in enable state, we should 
	 * set it into disable state
	*/
	request_region ( EFER_REG, 2, SIO_WDT_DEV_NAME );

	/* Enter config mode */
	outb ( 0x87, EFER_REG );
	outb ( 0x87, EFER_REG );
	outb ( 0x07, EFIR_REG );
	outb ( SIO_WDT_LOGIC_DEV_ID, EFDR_REG );
	
	outb ( 0x30, EFIR_REG );
	temp = inb ( EFDR_REG );
	temp &= 0xFE;
	outb ( temp, EFDR_REG );

	/* Clear flag */
	outb ( 0xF2, EFIR_REG );
	outb ( 0x0, EFDR_REG );

	/* Write zero to disable the timer */
	outb ( 0xF1, EFIR_REG );
	outb ( 0x00, EFDR_REG );

	/* Exit config mode */
	outb ( 0xAA, EFER_REG );

	release_region ( EFER_REG, 2 );
	
	printk ( "sio_watchdog init.\n" );
	return 0;
	
err2:
	for ( i = 0; i < 3; i++ )
	{
		device_remove_file ( &(( sio_wdt_dev->sio_wdt_platform_dev)->dev ),  
										&( sio_wdt_dev_ctrl[i].dev_attr )) ;
	}
	misc_deregister ( &sio_watchdog_miscdev );
	platform_device_unregister ( sio_wdt_dev->sio_wdt_platform_dev );
err1:
	platform_device_put ( sio_wdt_dev->sio_wdt_platform_dev );
err0:
	kfree ( sio_wdt_dev );
exit:
	printk ( "sio_watchdog init failed.\n" );
	return -EAGAIN;
}

static void __exit sio_watchdog_exit ( void )
{
	int i;

	for ( i = 0; i < 3; i++ )
	{
		device_remove_file ( &(( sio_wdt_dev->sio_wdt_platform_dev)->dev ),  
										&( sio_wdt_dev_ctrl[i].dev_attr )) ;
	}
	misc_deregister ( &sio_watchdog_miscdev );
	platform_device_unregister ( sio_wdt_dev->sio_wdt_platform_dev );
	kfree ( sio_wdt_dev );
	printk ( "sio_watchdog_exit.\n" );
}

module_init ( sio_watchdog_init );
module_exit ( sio_watchdog_exit );

MODULE_LICENSE("GPL");
MODULE_VERSION(VERSION_STRING);

