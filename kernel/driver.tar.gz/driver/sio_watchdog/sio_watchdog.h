#ifndef __SIO_WATCHDOG_H__
#define __SIO_WATCHDOG_H__

#define SIO_WDT_ENABLE			0x56
#define SIO_WDT_DISABLE		0x57
#define SIO_WDT_SET_TIME		0x58
#define SIO_WDT_FEED			0x59

#define SIO_WDT_2_ENABLE		0x5A
#define SIO_WDT_2_DISABLE		0x5B

#endif

