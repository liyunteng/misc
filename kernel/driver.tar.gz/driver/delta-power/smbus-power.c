#include <linux/init.h>
#include <linux/module.h>
#include <linux/io.h>
#include <linux/proc_fs.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/ctype.h>
#include <linux/errno.h>
#include <linux/cdev.h>
#include <linux/sched.h>
#include <linux/mm.h>

#include <linux/i2c.h>
#include <linux/sched.h>
#include <linux/workqueue.h>
#include <linux/timer.h>
#include <linux/delay.h>
#include <linux/semaphore.h>
#include <linux/mutex.h>

#include <linux/version.h>

#define MODULE_NAME "smbus-power"
#define POWER_INFO1 "module1"
#define POWER_INFO2 "module2"
#define VERSION_STRING	"1.2 Beta"

#define POWER_ABOVE 0xb2
#define POWER_BELOW 0xb0

/*
 * NCT6106 constants
 */
#define SIO_DEV_NAME						"NCT6106D"
#define SIO_ACCESS_DELAY					10			/* 10ms*/
#define EFER_REG 0x2e
#define EFIR_REG EFER_REG
#define EFDR_REG (EFIR_REG+1)

#define NCT6106D_SMBUS_BASE_ADDR			0x2a0
#define NCT6106D_SMBUS_SMDATA_OFFSET		0x00
#define NCT6106D_SMBUS_SMWRSIZE_OFFSET		0x01
#define NCT6106D_SMBUS_OPERTPYE_OFFSET		0x02
#define NCT6106D_SMBUS_SMIDX_OFFSET			0x03
#define NCT6106D_SMBUS_SMCTL_OFFSET			0x04
#define NCT6106D_SMBUS_SMADDR_OFFSET		0x05
#define NCT6106D_SMBUS_SMCTL3_OFFSET		0x0e

#define NCT6106D_SMBUS_OPER_MODE_MASK	0x0F
#define NCT6106D_SMBUS_READ_BYTE_MODE	(0x00)
#define NCT6106D_SMBUS_READ_WORD_MODE	(0x01)
#define NCT6106D_SMBUS_READ_BLOCK_MODE	(0x02)
#define NCT6106D_SMBUS_WRITE_BYTE_MODE	(0x08)
#define NCT6106D_SMBUS_WRITE_WORD_MODE	(0x09)
#define NCT6106D_SMBUS_WRITE_BLOCK_MODE	(0x0A)

#define NCT6106D_SMCTL_MANUAL_ENABLE	( 1 << 7 )
#define NCT6106D_SMCTL_CRC8_ENABLE		( 1 << 5 )

/*
 * Super-I/O constants
 */
#define NCT6106_LD_HWM		0x0b
#define SIO_REG_LDSEL		0x07	/* Logical device select */
#define SIO_REG_ENABLE		0x30	/* Logical device enable */
#define SIO_REG_DEVID		0x20	/* Device ID (2 bytes) */
#define SIO_NCT6106_ID		0xC450
#define SIO_ID_MASK			0xFFF0

static int debug = 0;
module_param(debug, int, 0);
MODULE_PARM_DESC(debug, "Debug switch(0 off; 1 on, default 0)");

static int fan_speed_min = 40;
module_param(fan_speed_min, int, 0);
MODULE_PARM_DESC(fan_speed_min, "Minimum fan speed(percentage, default 40)");

/*
 * smbus error status
*/
#define SMBUS_ADDR_NO_ACK			( 1 << 5 )
#define SMBUS_TIME_OUT				( 1 << 4 )
#define SMBUS_BUS_ERROR				( 1 << 2 )
#define SMBUS_NACK					( 1 << 1 )

/*
 * Enable / Disable print the err debug information
*/
#define SMBUS_ERR_DEBUG_ENABLE	1
#define SMBUS_RETRY_TIMES			0


struct psu_monitor_target
{
	char target_name[30];
	u8 target_offset_lo;
	u8 target_offset_hi;
	u16 target_value;
};

struct pic_i2c_psu 
{
	struct i2c_client *pic_i2c_client;
	struct timer_list pic_i2c_access_timer;
	struct psu_monitor_target **target_data;
	struct work_struct pic_i2c_access_work_struct;
	u16 psu_temp_test;
	int psu_info_via_pic;
	struct mutex smbus_mutex;
};

//static struct pic_i2c_psu *pic_i2c_psu_data;

static inline void
superio_outb(int ioreg, int reg, int val)
{
	outb(reg, ioreg);
	outb(val, ioreg + 1);
}

static inline int
superio_inb(int ioreg, int reg)
{
	outb(reg, ioreg);
	return inb(ioreg + 1);
}

static inline void
superio_select(int ioreg, int ld)
{
	outb(SIO_REG_LDSEL, ioreg);
	outb(ld, ioreg + 1);
}

static inline void
superio_enter(int ioreg)
{
	outb(0x87, ioreg);
	outb(0x87, ioreg);
}

static inline void
superio_exit(int ioreg)
{
	outb(0x02, ioreg);
	outb(0x02, ioreg + 1);
}

void _smbus_delay(unsigned int d)
{
	unsigned long long count = d * 1000;
	while(count--)
		inb(0x80);
}

/*
 * Added by Karlwolves 2013-8-8
 * Soft reset the smbus function module in nct6106
*/
static void __smbus_module_soft_reset( void )
{
	/*
	 * Set the bit4 of SMCTL register will trigger a soft reset of smbus module in nct6106
	*/
	outb ( 0x40, 0x2a0 + 4 );

	/*
	 * Since no flag in the register to indicate the completion of the soft reset,
	 * we can just wait for a while
	*/
	_smbus_delay( 10 );
}

unsigned char smbus_read_byte ( unsigned char slave_addr, unsigned char cmd )
{
	unsigned char retval;
	unsigned int retry_times = SMBUS_RETRY_TIMES;
	int i;

	
retry:
	/* Specify the address */
	outb ( slave_addr, NCT6106D_SMBUS_BASE_ADDR + NCT6106D_SMBUS_SMADDR_OFFSET );

	/* specify the cmd */
	outb( cmd, NCT6106D_SMBUS_BASE_ADDR + NCT6106D_SMBUS_SMIDX_OFFSET );

	/* specify the smbus oper type, write word*/
	outb ( NCT6106D_SMBUS_READ_BYTE_MODE & NCT6106D_SMBUS_OPER_MODE_MASK,
			NCT6106D_SMBUS_BASE_ADDR + NCT6106D_SMBUS_OPERTPYE_OFFSET );

	/* manual mode set */
	outb ( NCT6106D_SMCTL_MANUAL_ENABLE,
			NCT6106D_SMBUS_BASE_ADDR + NCT6106D_SMBUS_SMCTL_OFFSET );

	/* wait if data has read */
	for ( i = 0; i < 10; i++)
	{
		if (( inb( NCT6106D_SMBUS_BASE_ADDR + NCT6106D_SMBUS_SMCTL3_OFFSET ) & 0x01 )
				!= 0x01 )
		{
			/* The smbus data fifi is empty now, the data has been send*/
			break;
		}
		_smbus_delay(1);
	}

	if ( i >= 10 )
	{
		if ( retry_times > 0 )
		{
			retry_times--;
			__smbus_module_soft_reset ();
			goto retry;
		}
		else
		{
			return 0xFF;
		}
	}

	retval = inb ( NCT6106D_SMBUS_BASE_ADDR + NCT6106D_SMBUS_SMDATA_OFFSET );

	return retval;

}

unsigned short smbus_read_word(unsigned char slave_addr, unsigned int cmd)
{
	unsigned short retval;
	unsigned int retry_times = SMBUS_RETRY_TIMES;
	unsigned char lo8,hi8;
	int i;
	u8 temp;

retry:

	outb(slave_addr, 0x2a0 + 5);	// slave address field
	outb(cmd, 0x2a0 + 3);		// command
	outb(0x1, 0x2a0 + 2);		// read word operation
	outb(0x80, 0x2a0 + 4);		// manual mode set


	//wait if data ready
	for ( i=0; i < 10; i++ )
	{
		temp = inb ( 0x2ae );
		if (( temp & 1) != 1)
			break;
		_smbus_delay(5);
	}

	if (i>=10)
	{
		/*
		 * The data is not ready, we'd better check the smbus error status
		 * Here we just print the error status, this will help up us to locate the
		 * smbus error
		*/
		if (debug)
		{
			unsigned char smbus_err_status = inb ( 0x2a9 );
			if ( smbus_err_status & SMBUS_ADDR_NO_ACK )
			{
				printk( KERN_NOTICE "SMBUS_ADDR_NO_ACK" );
			}

			if ( smbus_err_status & SMBUS_TIME_OUT )
			{
				printk( KERN_NOTICE "SMBUS_TIME_OUT" );
			}

			if ( smbus_err_status & SMBUS_BUS_ERROR )
			{
				printk( KERN_NOTICE "SMBUS_BUS_ERROR" );
			}

			if ( smbus_err_status & SMBUS_NACK )
			{
				printk( KERN_NOTICE "SMBUS_NACK" );
			}
		}

		/*
		 * Soft reset the smbus module in nct6106,
		*/
		if ( retry_times > 0 )
		{
			retry_times--;
			__smbus_module_soft_reset ();
			goto retry;
		}

		if (debug)
			printk(KERN_NOTICE "wrong io: %.2x\n", inb(0x2ae));
		return -1;
	}

	// data ready
	lo8 = inb(0x2a0);
	_smbus_delay(1);
	hi8 = inb(0x2a0);
	retval = (hi8<<8) | lo8;

	return retval;
}

/*
 * data_write only receive the linear value which transfered by raw data
 * so the caller must do the data transfer before calling this function
 *
 * I am not sure the value in register NCT6106D_SMBUS_SMWRSIZE_OFFSET will
 * subtract if one byte was trasmitted success.
*/
int smbus_write_word ( unsigned char slave_addr,
				unsigned char cmd, unsigned short  data_write )
{
	unsigned int retry_times = SMBUS_RETRY_TIMES;
	int i;
	volatile u8 temp;

retry :
	/* Specify the address */
	outb ( slave_addr, NCT6106D_SMBUS_BASE_ADDR + NCT6106D_SMBUS_SMADDR_OFFSET );

	/* specify the cmd */
	outb( cmd, NCT6106D_SMBUS_BASE_ADDR + NCT6106D_SMBUS_SMIDX_OFFSET );

	/* specify the smbus oper type, write word*/
	outb ( NCT6106D_SMBUS_WRITE_WORD_MODE & NCT6106D_SMBUS_OPER_MODE_MASK,
			NCT6106D_SMBUS_BASE_ADDR + NCT6106D_SMBUS_OPERTPYE_OFFSET );

	/* specify the write length, two bytes */
	outb ( sizeof ( data_write ),
			NCT6106D_SMBUS_BASE_ADDR + NCT6106D_SMBUS_SMWRSIZE_OFFSET  );

	/* manual mode set */
	outb ( NCT6106D_SMCTL_MANUAL_ENABLE | NCT6106D_SMCTL_CRC8_ENABLE,
			NCT6106D_SMBUS_BASE_ADDR + NCT6106D_SMBUS_SMCTL_OFFSET );

	/* specify the low byte data to be written on smbus */
	outb ( data_write & 0xff,
			NCT6106D_SMBUS_BASE_ADDR + NCT6106D_SMBUS_SMDATA_OFFSET );

	/* wait if data has write over */
	for ( i = 0; i < 10; i++) 
	{
		temp = inb( NCT6106D_SMBUS_BASE_ADDR + NCT6106D_SMBUS_SMCTL3_OFFSET );
		if ((   temp & 0x01 ) == 0x01 )
			break;
		_smbus_delay(50);
	}

	if ( i >= 10 )
	{
		if (debug)
		{
			unsigned char smbus_err_status = inb ( 0x2a9 );
			if ( smbus_err_status & SMBUS_ADDR_NO_ACK )
			{
				printk( KERN_NOTICE "SMBUS_ADDR_NO_ACK" );
			}

			if ( smbus_err_status & SMBUS_TIME_OUT )
			{
				printk( KERN_NOTICE "SMBUS_TIME_OUT" );
			}

			if ( smbus_err_status & SMBUS_BUS_ERROR )
			{
				printk( KERN_NOTICE "SMBUS_BUS_ERROR" );
			}

			if ( smbus_err_status & SMBUS_NACK )
			{
				printk( KERN_NOTICE "SMBUS_NACK" );
			}
		}
		if ( retry_times > 0 )
		{
			retry_times--;
			__smbus_module_soft_reset ();
			goto retry;
		}
		else
		{
			return -EAGAIN;
		}
	}

	/* specify the second byte data to be written on smbus */
	outb (( data_write >> 8 ) & 0xff,
			NCT6106D_SMBUS_BASE_ADDR + NCT6106D_SMBUS_SMDATA_OFFSET );

	/* wait if data has write over */
	for ( i = 0; i < 10; i++ )
	{
		temp = inb( NCT6106D_SMBUS_BASE_ADDR + NCT6106D_SMBUS_SMCTL3_OFFSET );
		if ((   temp & 0x01 ) == 0x01 )
			break;
		_smbus_delay(50);
	}

	if ( i >= 10 )
	{
		if (debug)
		{
			unsigned char smbus_err_status = inb ( 0x2a9 );
			if ( smbus_err_status & SMBUS_ADDR_NO_ACK )
			{
				printk( KERN_NOTICE "SMBUS_ADDR_NO_ACK" );
			}

			if ( smbus_err_status & SMBUS_TIME_OUT )
			{
				printk( KERN_NOTICE "SMBUS_TIME_OUT" );
			}

			if ( smbus_err_status & SMBUS_BUS_ERROR )
			{
				printk( KERN_NOTICE "SMBUS_BUS_ERROR" );
			}

			if ( smbus_err_status & SMBUS_NACK )
			{
				printk( KERN_NOTICE "SMBUS_NACK" );
			}
		}
		if ( retry_times > 0 )
		{
			retry_times--;
			__smbus_module_soft_reset ();
			goto retry;
		}
		else
		{
			return -EAGAIN;
		}
	}

	return 0;
}

static int nct6106_init(void)
{
	// SMBus Init
	superio_enter(EFER_REG);
	superio_select(EFIR_REG, NCT6106_LD_HWM);
	superio_outb(EFIR_REG, 0x1b, 0x01);
	superio_outb(EFIR_REG, SIO_REG_ENABLE, 0x01);
	return 0;
}

static void nct6106_exit(void)
{
	superio_exit(EFER_REG);
}

static struct proc_dir_entry *power_entry1, *power_entry2, *power_dir;

static int __pic_get_power_info ( char *info_msg, unsigned char power_module )
{
#define POWER_ABOVE_TARGET_OFFSET 		6
#define POWER_BELOW_TARGET_OFFSET 		0
#define POWER_TARGET_VALID_CHECK_OFFSET 1

	unsigned short sts, vin, vout, fan, temp_amb, temp_hs;
	int index = 0;
	struct pic_i2c_psu *pic_i2c_psu_data = ( struct pic_i2c_psu *)( power_entry1->data );

	if ( power_module == POWER_ABOVE )
	{
		index = POWER_ABOVE_TARGET_OFFSET;
	}
	else if ( power_module == POWER_BELOW )
	{
		index = POWER_BELOW_TARGET_OFFSET;
	}

	sts = (( struct psu_monitor_target *)(( pic_i2c_psu_data->target_data )) + index )->target_value;
	vin = (( struct psu_monitor_target *)(( pic_i2c_psu_data->target_data )) + index +1 )->target_value;
	vout = (( struct psu_monitor_target *)(( pic_i2c_psu_data->target_data )) + index + 2 )->target_value;
	fan = (( struct psu_monitor_target *)(( pic_i2c_psu_data->target_data )) + index + 3 )->target_value;
	temp_amb = (( struct psu_monitor_target *)(( pic_i2c_psu_data->target_data )) + index + 4 )->target_value;
	temp_hs = (( struct psu_monitor_target *)(( pic_i2c_psu_data->target_data )) + index + 5 )->target_value;
	
	sprintf(info_msg, "%.4x %.4x %.4x %.4x %.4x %.4x",
		sts, vin, vout, fan, temp_amb, temp_hs);

	return 0;
}

static int __smbus_get_power_info(char *info_msg, unsigned char power_module)
{
	int ret = -1;
	unsigned short sts, vin, vout, fan, temp_amb, temp_hs;
	unsigned char vout_mode;
	int i;

#define VOUT_MODE_N_STANDARD		(0x17)

	if (nct6106_init())
	{
		printk(KERN_NOTICE "ID(hi): %.2x\n", superio_inb(EFIR_REG, SIO_REG_DEVID));
		printk(KERN_NOTICE "ID(lo): %.2x\n", superio_inb(EFIR_REG, SIO_REG_DEVID+1));
		sprintf(info_msg, "ffff ffff ffff ffff ffff\n");
		goto finish;
	}
	sts = smbus_read_word(power_module, 0x79);
	vin = smbus_read_word(power_module, 0x88);
	vout = smbus_read_word(power_module, 0x8b);
	fan = smbus_read_word(power_module, 0x90);
	temp_amb = smbus_read_word(power_module, 0x8d);
	temp_hs = smbus_read_word(power_module, 0x8e);
	
	vout_mode = smbus_read_byte ( power_module, 0x20 );	
	if (( vout_mode & 0x1F ) >= VOUT_MODE_N_STANDARD )
	{
		i = ( vout_mode & 0x1F ) - VOUT_MODE_N_STANDARD;
		while ( i-- )
		{
			vout <<= 1;
		}
	}
	else
	{
		i = VOUT_MODE_N_STANDARD - ( vout_mode & 0x1F );
		while ( i-- )
		{
			vout >>= 1;
		}
	}
	sprintf(info_msg, "%.4x %.4x %.4x %.4x %.4x %.4x",
		sts, vin, vout, fan, temp_amb, temp_hs);

	ret = 0;

finish:
	nct6106_exit();
	return ret;
}

struct power_status {
	unsigned char module;
	unsigned short fan_speed;
	int online;
};
static struct power_status powers_sts[2];

#if LINUX_VERSION_CODE <= KERNEL_VERSION ( 2, 6, 32 )
long long simple_strtoll(const char *cp, char **endp, unsigned int base)
{
        if(*cp=='-')
                return -simple_strtoull(cp + 1, endp, base);
        return simple_strtoull(cp, endp, base);
}
#endif

static ssize_t power_proc_write(struct file *file, const char *data, size_t len,
							loff_t *offset, struct power_status *power_sts)
{
	char msg[256];
	char *p = msg;
	int action;
	int val, new_fan_speed;
	struct pic_i2c_psu *pic_i2c_psu_data = ( struct pic_i2c_psu * )( file->private_data );

	if ( pic_i2c_psu_data->psu_info_via_pic == 1 )
	{
		return -EPERM;
	}

	if (len > sizeof(msg))
		return -EINVAL;;

	memset(msg, 0x0, sizeof(msg));
	if (copy_from_user(msg, data, len) != 0)
		return -EFAULT;

	if (strncmp(p, "fan_speed", 9) != 0)
	{
		return -EINVAL;
	}
	p += 9;
	while (isspace(*p) && *p != '\0')
		p++;

	if (0 == strncmp(p, "set", 3))
	{
		action = 0;
		p += 3;
	} else if (0 == strncmp(p, "inc", 3)) {
		action = 1;
		p += 3;
	} else if (0 == strncmp(p, "dec", 3)) {
		action = 2;
		p += 3;
	} else {
		return -EINVAL;
	}

	while (isspace(*p) && *p != '\0')
		p++;
	if (!isdigit(*p))
	{
		return -EINVAL;
	}

	val = simple_strtoll(p, NULL, 0);
	if (0 == action)
	{
		new_fan_speed = val;
	} else if (1 == action) {
		new_fan_speed = power_sts->fan_speed + val;
		if (new_fan_speed > 100)
			new_fan_speed = 100;
	} else if (2 == action) {
		new_fan_speed = power_sts->fan_speed - val;
	}

	if (new_fan_speed > 100)
	{
		new_fan_speed = 100;
	} else if (new_fan_speed < fan_speed_min) {
		new_fan_speed = fan_speed_min;
	}
	
#if 1
	if (smbus_write_word(power_sts->module, 0x3b, new_fan_speed) == 0) {
		power_sts->fan_speed = new_fan_speed;
	}
#else
	pic_i2c_psu_data->psu_temp_test = new_fan_speed;
	pic_i2c_psu_data->psu_temp_test |= 0xf800;
#endif
	*offset += len;
	return len;
}

static ssize_t power_proc_read(struct file *file, char *data, size_t len,
							loff_t *offset, struct power_status *power_sts)
{
	char msg[256];
	ssize_t msg_len;
	int ret;

	struct pic_i2c_psu *pic_i2c_psu_data = ( struct pic_i2c_psu * )( file->private_data);
	
	if (*offset > 0)
		return 0;

	if ( 0 == pic_i2c_psu_data->psu_info_via_pic )
	{
		ret = __smbus_get_power_info(msg, power_sts->module);
		if (ret < 0 && power_sts->online)
		{
			power_sts->online = 0;
		} else if (0 == ret && !power_sts->online) {
			smbus_write_word(power_sts->module, 0x3b, fan_speed_min);
			power_sts->online = 1;
			power_sts->fan_speed = fan_speed_min;
		}
	}
	else
	{
		ret = __pic_get_power_info ( msg, power_sts->module );
		if (ret < 0 && power_sts->online)
		{
			power_sts->online = 0;
		} 
		else if (0 == ret && !power_sts->online) 
		{
			power_sts->online = 1;
		}
	}
	
	msg_len = strlen(msg);
	if (copy_to_user(data, msg, msg_len) != 0)
		return -EFAULT;

	*offset += msg_len;
	return msg_len;
}

static int power_module1_open (struct inode *inode, struct file *filp)
{
	filp->private_data = power_entry1->data;
	return 0;
}

static ssize_t power_module1_read(struct file *file, char *data,
									size_t len, loff_t *offset)
{
	return power_proc_read(file, data, len, offset, &powers_sts[0]);
}

static ssize_t power_module1_write(struct file *file, const char *data,
									size_t len, loff_t *offset)
{
	return power_proc_write(file, data, len, offset, &powers_sts[0]);
}

static int power_module2_open (struct inode *inode, struct file *filp)
{
	filp->private_data = power_entry1->data;
	return 0;
}

static ssize_t power_module2_read(struct file *file, char *data,
									size_t len, loff_t *offset)
{
	return power_proc_read(file, data, len, offset, &powers_sts[1]);
}

static ssize_t power_module2_write(struct file *file, const char *data,
									size_t len, loff_t *offset)
{
	return power_proc_write(file, data, len, offset, &powers_sts[1]);
}

static struct file_operations power_module1_fops = {
	.owner = THIS_MODULE,
	.open = power_module1_open,
	.read = power_module1_read,
	.write = power_module1_write
};

static struct file_operations power_module2_fops = {
	.owner = THIS_MODULE,
	.open = power_module2_open,
	.read = power_module2_read,
	.write = power_module2_write
};


enum chip_types { pic_psu };


static const unsigned short normal_i2c[] = {
	0x30, I2C_CLIENT_END
};

#if LINUX_VERSION_CODE <= KERNEL_VERSION ( 2, 6, 32 )
static const unsigned short probe_i2c[] = {I2C_CLIENT_END, I2C_CLIENT_END};
static const unsigned short ignore_i2c[] = {I2C_CLIENT_END, I2C_CLIENT_END};
static const struct i2c_client_address_data client_addr_data = {
	.normal_i2c	= normal_i2c,
	.probe = probe_i2c,
	.ignore = ignore_i2c
};
#endif
static const struct i2c_device_id pic_i2c_id[] = {
	{ "pic_i2c_psu", pic_psu },
	{ }
};

#define PSU_MAX_NUM		2
#define PSU_MAX_TARGET	6


#define PIC_FIRMWARE_VERSION_LO         		0x00
#define PIC_FIRMWARE_VERSION_HI         		0x01

#define PSU_ABOVE_STATUS_REG_LO         		0xC0
#define PSU_ABOVE_STATUS_REG_HI         		0xC1
#define PSU_ABOVE_VIN_REG_LO                    	0xC2
#define PSU_ABOVE_VIN_REG_HI                    	0xC3
#define PSU_ABOVE_VOUT_REG_LO           		0xC4
#define PSU_ABOVE_VOUT_REG_HI          		0xC5
#define PSU_ABOVE_FAN_SPEED_LO          		0xC6
#define PSU_ABOVE_FAN_SPEED_HI          		0xC7
#define PSU_ABOVE_TEMP_AMB_LO           		0xC8
#define PSU_ABOVE_TEMP_AMB_HI           		0xC9
#define PSU_ABOVE_TEMP_HS_LO                    	0xCA
#define PSU_ABOVE_TEMP_HS_HI                    	0xCB

#define PSU_ABOVE_FAN_SPEED_DUTY			0xCF
 
#define PSU_TEMP_LOW_LIMIT				0xCC		//-- used for set the low limit of the temprature of the psu
#define PSU_TEMP_MIDDLE_LIMIT				0xCD
#define PSU_TEMP_HIGH_LIMIT				0xCE		//-- used for set the high limit of the temprature of the psu
 
#define PSU_BELOW_STATUS_REG_LO         	0xD0
#define PSU_BELOW_STATUS_REG_HI         		0xD1
#define PSU_BELOW_VIN_REG_LO                    	0xD2
#define PSU_BELOW_VIN_REG_HI                    	0xD3
#define PSU_BELOW_VOUT_REG_LO           		0xD4
#define PSU_BELOW_VOUT_REG_HI           		0xD5
#define PSU_BELOW_FAN_SPEED_LO          		0xD6
#define PSU_BELOW_FAN_SPEED_HI          		0xD7
#define PSU_BELOW_TEMP_AMB_LO           		0xD8
#define PSU_BELOW_TEMP_AMB_HI           		0xD9
#define PSU_BELOW_TEMP_HS_LO                    	0xDA
#define PSU_BELOW_TEMP_HS_HI                    	0xDB

#define PSU_EN_MANUAL_SET_FAN_SPEED		0xDC

#define PSU_BELOW_FAN_SPEED_DUTY			0xDF

#define WORK_QUEUE_THREAD_NAME			"pic_i2c_access_thread"

#define PIC_I2C_ACCESS_TIME_INT			2000

#define I2C_SMBUS_XFER_RETRY_TIMES		3

struct psu_device_attribute
{
	struct device_attribute dev_attr;
	int index;
	unsigned char pic_i2c_cmd;
};

#define SMBUS_POWER_DEV_ATTR(_name, _mode, _show, _store, _index, _cmd)	\
	{ .dev_attr = __ATTR(_name, _mode, _show, _store),	\
	  .index = _index, \
	  .pic_i2c_cmd = _cmd}


static ssize_t psu_ctrl_info_store ( struct device *dev, 
								struct device_attribute *attr,
								const char *buf,
								size_t count )
{
	unsigned long val = simple_strtoul( buf, NULL, 10 );
	s32 i2c_ret_val;
	
	struct pic_i2c_psu *pic_i2c_psu_data = ( struct pic_i2c_psu *)( power_entry1->data );

	struct psu_device_attribute *psu_dev_attr = container_of ( attr, struct psu_device_attribute, dev_attr );

	mutex_lock ( &( pic_i2c_psu_data->smbus_mutex ));

	i2c_ret_val = i2c_smbus_write_byte_data ( pic_i2c_psu_data->pic_i2c_client,
											psu_dev_attr->pic_i2c_cmd,
											val );
	mutex_unlock ( &( pic_i2c_psu_data->smbus_mutex ));

	if ( i2c_ret_val < 0 )
	{
		return i2c_ret_val;
	}

	return count;
	
	
}  



static struct psu_device_attribute psu_device_ctrl[] = 
{
	SMBUS_POWER_DEV_ATTR ( psu_fan_manual_enable, S_IWUSR, NULL, psu_ctrl_info_store, 0, PSU_EN_MANUAL_SET_FAN_SPEED ),
	SMBUS_POWER_DEV_ATTR ( psu_above_fan_speed_duty, S_IWUSR, NULL, psu_ctrl_info_store, 1, PSU_ABOVE_FAN_SPEED_DUTY ),
	SMBUS_POWER_DEV_ATTR ( psu_below_fan_speed_duty, S_IWUSR, NULL, psu_ctrl_info_store, 2, PSU_BELOW_FAN_SPEED_DUTY ),
	SMBUS_POWER_DEV_ATTR ( psu_temp_high_limit, S_IWUSR, NULL, psu_ctrl_info_store, 3, PSU_TEMP_HIGH_LIMIT ),
	SMBUS_POWER_DEV_ATTR ( psu_temp_middle_limit, S_IWUSR, NULL, psu_ctrl_info_store, 4, PSU_TEMP_MIDDLE_LIMIT ),
	SMBUS_POWER_DEV_ATTR ( psu_temp_low_limit, S_IWUSR, NULL, psu_ctrl_info_store, 5, PSU_TEMP_LOW_LIMIT ),

};

static const struct psu_monitor_target target_const_data[PSU_MAX_NUM][PSU_MAX_TARGET] =
{
	{
		{ "psu_below_status", PSU_BELOW_STATUS_REG_LO, PSU_BELOW_STATUS_REG_HI, 0 },
		{ "psu_below_vin", PSU_BELOW_VIN_REG_LO, PSU_BELOW_VIN_REG_HI, 0 },
		{ "psu_below_vout", PSU_BELOW_VOUT_REG_LO, PSU_BELOW_VOUT_REG_HI, 0 },
		{ "psu_below_fan_speed", PSU_BELOW_FAN_SPEED_LO, PSU_BELOW_FAN_SPEED_HI, 0 },
		{ "psu_below_temp_amb", PSU_BELOW_TEMP_AMB_LO, PSU_BELOW_TEMP_AMB_HI, 0 },
		{ "psu_below_temp_hs", PSU_BELOW_TEMP_HS_LO, PSU_BELOW_TEMP_HS_HI, 0 }
	},

	{
		{ "psu_above_status", PSU_ABOVE_STATUS_REG_LO, PSU_ABOVE_STATUS_REG_HI, 0 },
		{ "psu_above_vin", PSU_ABOVE_VIN_REG_LO, PSU_ABOVE_VIN_REG_HI, 0 },
		{ "psu_above_vout", PSU_ABOVE_VOUT_REG_LO, PSU_ABOVE_VOUT_REG_HI, 0 },
		{ "psu_above_fan_speed", PSU_ABOVE_FAN_SPEED_LO, PSU_ABOVE_FAN_SPEED_HI, 0 },
		{ "psu_above_temp_amb", PSU_ABOVE_TEMP_AMB_LO, PSU_ABOVE_TEMP_AMB_HI, 0 },
		{ "psu_above_temp_hs", PSU_ABOVE_TEMP_HS_LO, PSU_ABOVE_TEMP_HS_HI, 0 }
	}
};


static struct workqueue_struct *pic_i2c_access_single_thread_workqueue;

/*
 * Call back funtion of the timer
*/
static void pic_i2c_access_timer_callback ( unsigned long timer_data )
{
	struct pic_i2c_psu *pic_i2c_psu_data = ( struct pic_i2c_psu *)( timer_data );
	queue_work ( pic_i2c_access_single_thread_workqueue, &( pic_i2c_psu_data->pic_i2c_access_work_struct ));
	
	mod_timer ( &( pic_i2c_psu_data )->pic_i2c_access_timer,
					jiffies + msecs_to_jiffies( PIC_I2C_ACCESS_TIME_INT ));	
}

static void pic_i2c_access_psu_data_fun( struct work_struct *p )
{
	/*
	 * we access pic via i2c in this function
	*/
	u8 temp;
	u16 read_back;
	int i,j;

	struct pic_i2c_psu *pic_i2c_psu_data = container_of ( p, struct pic_i2c_psu, pic_i2c_access_work_struct );

	for ( i = 0; i < PSU_MAX_NUM; i++ )
	{
		for ( j = 0; j < PSU_MAX_TARGET; j++ )
		{
			mutex_lock ( &( pic_i2c_psu_data->smbus_mutex ));
			temp = i2c_smbus_read_byte_data ( pic_i2c_psu_data->pic_i2c_client, 
												(( struct psu_monitor_target *)( pic_i2c_psu_data->target_data ) + ( i * PSU_MAX_TARGET + j ))->target_offset_hi );
			mutex_unlock ( &( pic_i2c_psu_data->smbus_mutex ));
			read_back = temp;

			mutex_lock ( &( pic_i2c_psu_data->smbus_mutex ));
			temp = i2c_smbus_read_byte_data ( pic_i2c_psu_data->pic_i2c_client, 
												(( struct psu_monitor_target *)( pic_i2c_psu_data->target_data ) + ( i * PSU_MAX_TARGET + j ))->target_offset_lo );
			mutex_unlock ( &( pic_i2c_psu_data->smbus_mutex ));
			read_back <<= 8;
			read_back += temp;

			(( struct psu_monitor_target *)( pic_i2c_psu_data->target_data ) + ( i * PSU_MAX_TARGET + j ))->target_value = read_back;

		}
	}
}

static int pic_i2c_probe(struct i2c_client *client, const struct i2c_device_id *id )
{
	u8 temp;
	u16 read_back;
	int err;
	int i,j;

	struct pic_i2c_psu *pic_i2c_psu_data = ( struct pic_i2c_psu *)( power_entry1->data );
	
	pic_i2c_psu_data->pic_i2c_client = client;

	pic_i2c_psu_data->target_data = kzalloc ( PSU_MAX_NUM * PSU_MAX_TARGET * sizeof ( struct psu_monitor_target ), GFP_KERNEL );
	if ( pic_i2c_psu_data->target_data == NULL )
	{
		printk(KERN_ERR MODULE_NAME "fail to malloc memory!\n");
		return -ENOMEM;
	}
	
	memcpy (  pic_i2c_psu_data->target_data ,
				&target_const_data[0][0],
				PSU_MAX_NUM * PSU_MAX_TARGET *sizeof ( struct psu_monitor_target ));

	/*
	 * To avoid the application access the target value before the timer fired for first time
	 * we read the psu to update the target value
	*/
	for ( i = 0; i < PSU_MAX_NUM; i++ )
	{
		for ( j = 0; j < PSU_MAX_TARGET; j++ )
		{
			temp = i2c_smbus_read_byte_data ( pic_i2c_psu_data->pic_i2c_client, 
												(( struct psu_monitor_target *)( pic_i2c_psu_data->target_data ) + ( i * PSU_MAX_TARGET + j ))->target_offset_hi );
			read_back = temp;

			
			temp = i2c_smbus_read_byte_data ( pic_i2c_psu_data->pic_i2c_client, 
												(( struct psu_monitor_target *)( pic_i2c_psu_data->target_data ) + ( i * PSU_MAX_TARGET + j ))->target_offset_lo );
			read_back <<= 8;
			read_back += temp;

			(( struct psu_monitor_target *)( pic_i2c_psu_data->target_data ) + ( i * PSU_MAX_TARGET + j ))->target_value = read_back;

		}
	}

	
	/*
	 * We setup a timer to trrigger the access of pic via i2c each 5 s.
	 * Because the i2c_smbus_read_byte_data may cause a schedule(), so we can not
	 * access directly in the call back function of the timer, the task will be complete in
	 * a work queue.
	*/
	
	/* Create a single thread for the work queue*/
	pic_i2c_access_single_thread_workqueue =
		create_singlethread_workqueue ( WORK_QUEUE_THREAD_NAME );

	mutex_init ( &( pic_i2c_psu_data->smbus_mutex ));

	/* Construct a work struct */
	INIT_WORK ( &( pic_i2c_psu_data->pic_i2c_access_work_struct ),
					pic_i2c_access_psu_data_fun );
		

	setup_timer ( &( pic_i2c_psu_data->pic_i2c_access_timer ),
					pic_i2c_access_timer_callback,
					( unsigned long )pic_i2c_psu_data );
					
	mod_timer ( &( pic_i2c_psu_data )->pic_i2c_access_timer,
					jiffies + msecs_to_jiffies( PIC_I2C_ACCESS_TIME_INT ));

	for ( i = 0; i < ARRAY_SIZE(psu_device_ctrl); i++ )
	{
		err = device_create_file( & ( pic_i2c_psu_data->pic_i2c_client->dev ),  
										&( psu_device_ctrl[i].dev_attr ));
		if ( err )
		{
			goto error;
		}
		
	}

	pic_i2c_psu_data->psu_info_via_pic = 1;

	printk ( "pic_i2c_probe success.\n" );

	return 0;

error:
	for ( i= 0; i < ARRAY_SIZE ( psu_device_ctrl ); i++ )
	{
		device_remove_file ( & ( pic_i2c_psu_data->pic_i2c_client->dev ),  
										&( psu_device_ctrl[i].dev_attr ));
	}

	del_timer ( &( pic_i2c_psu_data->pic_i2c_access_timer ));
	pic_i2c_psu_data->psu_info_via_pic = 0;
	
	return -ENOMEM;
	
}

static int pic_i2c_remove(struct i2c_client *client )
{
	struct pic_i2c_psu *pic_i2c_psu_data = ( struct pic_i2c_psu *)( power_entry1->data );
	del_timer_sync ( &( pic_i2c_psu_data->pic_i2c_access_timer ));
	destroy_workqueue ( pic_i2c_access_single_thread_workqueue );
	kfree ( pic_i2c_psu_data->target_data );
	
	return 0;
}


#define I2C_SMBUS_READ_BYTE_RETRY(read_back,client,reg_index,retry_times) 	\
while (retry_times--) {																\
	read_back=i2c_smbus_read_byte_data (client,reg_index);								\
	if ( read_back >= 0 ) break;														\
}																					\
/*
 * Call back function, when pic was detected.
*/
#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,32)
static int pic_i2c_legacy_detect ( struct i2c_client *client, int kind, struct i2c_board_info *info )
{
	/*
	 * Here we read the firmware version of the mcu, and then check it.
	*/
	s32 i2c_read_back;
	u16 psu_above_vin, psu_below_vin;
	u32 i2c_smbus_xfter_retry = I2C_SMBUS_XFER_RETRY_TIMES;

	kind = kind;

	/*
	 * We read the vin of the two psu via pic mcu, if both of them are zero, 
	 * we treat this mcu does not have the ability to aceess the psu
	*/
	I2C_SMBUS_READ_BYTE_RETRY ( i2c_read_back, 
									client, 
									PSU_ABOVE_VIN_REG_LO, 
									i2c_smbus_xfter_retry );
	if ( i2c_read_back < 0 ) {
		goto i2c_detect_pic_err;
	}
	psu_above_vin = i2c_read_back;

	I2C_SMBUS_READ_BYTE_RETRY ( i2c_read_back, 
									client, 
									PSU_ABOVE_VIN_REG_HI, 
									i2c_smbus_xfter_retry );
	if ( i2c_read_back < 0 ) {
		goto i2c_detect_pic_err;
	}
	psu_above_vin <<= 8;
	psu_above_vin += i2c_read_back;

	I2C_SMBUS_READ_BYTE_RETRY ( i2c_read_back, 
									client, 
									PSU_BELOW_VIN_REG_LO, 
									i2c_smbus_xfter_retry );
	if ( i2c_read_back < 0 ) {
		goto i2c_detect_pic_err;
	}
	psu_below_vin = i2c_read_back;

	I2C_SMBUS_READ_BYTE_RETRY ( i2c_read_back, 
									client, 
									PSU_BELOW_VIN_REG_HI, 
									i2c_smbus_xfter_retry );
	if ( i2c_read_back < 0 ) {
		goto i2c_detect_pic_err;
	}
	psu_below_vin <<= 8;
	psu_below_vin += i2c_read_back;

	if (( psu_above_vin == 0x0000 ) && ( psu_below_vin == 0x0000 ))
	{
		printk ( "This pic does not have the ability to access the psu.\n" );
		return -ENODEV;
	}
	
	strlcpy ( info->type, "pic_i2c_psu", I2C_NAME_SIZE );

	return 0;
i2c_detect_pic_err:
	return -ENODEV;		
}
#else	
static int pic_i2c_detect(struct i2c_client *client, struct i2c_board_info *info )
{
	/*
	 * Here we read the firmware version of the mcu, and then check it.
	*/
	s32 i2c_read_back;
	u16 psu_above_vin, psu_below_vin;
	u32 i2c_smbus_xfter_retry = I2C_SMBUS_XFER_RETRY_TIMES;

	
	/*
	 * We read the vin of the two psu via pic mcu, if both of them are zero, 
	 * we treat this mcu does not have the ability to aceess the psu
	*/
	I2C_SMBUS_READ_BYTE_RETRY ( i2c_read_back, 
									client, 
									PSU_ABOVE_VIN_REG_LO, 
									i2c_smbus_xfter_retry );
	if ( i2c_read_back < 0 ) {
		goto i2c_detect_pic_err;
	}
	psu_above_vin = i2c_read_back;

	I2C_SMBUS_READ_BYTE_RETRY ( i2c_read_back, 
									client, 
									PSU_ABOVE_VIN_REG_HI, 
									i2c_smbus_xfter_retry );
	if ( i2c_read_back < 0 ) {
		goto i2c_detect_pic_err;
	}
	psu_above_vin <<= 8;
	psu_above_vin += i2c_read_back;

	I2C_SMBUS_READ_BYTE_RETRY ( i2c_read_back, 
									client, 
									PSU_BELOW_VIN_REG_LO, 
									i2c_smbus_xfter_retry );
	if ( i2c_read_back < 0 ) {
		goto i2c_detect_pic_err;
	}
	psu_below_vin = i2c_read_back;

	I2C_SMBUS_READ_BYTE_RETRY ( i2c_read_back, 
									client, 
									PSU_BELOW_VIN_REG_HI, 
									i2c_smbus_xfter_retry );
	if ( i2c_read_back < 0 ) {
		goto i2c_detect_pic_err;
	}
	psu_below_vin <<= 8;
	psu_below_vin += i2c_read_back;


	if (( psu_above_vin == 0x0000 ) && ( psu_below_vin == 0x0000 ))
	{
		printk ( "This pic does not have the ability to access the psu.\n" );
		return -ENODEV;
	}

	
	strlcpy ( info->type, "pic_i2c_psu", I2C_NAME_SIZE );

	return 0;

i2c_detect_pic_err:
	return -ENODEV;	
}
#endif

static struct i2c_driver pic_i2c_driver = 
{
	.driver =
	{
		.name = "pic_i2c_psu",
	},
	.probe = pic_i2c_probe,
	.remove = pic_i2c_remove,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,32)
	.detect = pic_i2c_detect,
	.address_list = normal_i2c,
#else
	.detect = pic_i2c_legacy_detect,
	.address_data = &client_addr_data,
#endif

	.id_table = pic_i2c_id,
	.class = I2C_CLASS_HWMON,
	
	
};

static int __init smbus_power_init(void)
{
	int retval;
	unsigned short nct6106_id;
	unsigned char hi,lo;
	struct pic_i2c_psu *pic_i2c_psu_data;

	if (nct6106_init())
	{
		printk(KERN_ERR "NCT6106 Init fail!\n");
		retval = -ENODEV;
		goto power_finish;
	}

	// Device ID Check
	hi = superio_inb(EFIR_REG, SIO_REG_DEVID);
	lo = superio_inb(EFIR_REG, SIO_REG_DEVID+1);
	nct6106_id = (hi<<8) | lo;

	if (SIO_NCT6106_ID != (nct6106_id & SIO_ID_MASK))
	{
		printk(KERN_ERR "The Device NCT6106D is not exist! (Bad ID: %.4x)\n",
				nct6106_id);
		goto power_finish;
	}
	printk(KERN_INFO "SMBus Power Module init! NCT6106D found! (Device ID: %.4x)\n",
			(nct6106_id & SIO_ID_MASK));

	/* set initial fan speed*/
	smbus_write_word(POWER_ABOVE, 0x3b, fan_speed_min);
	smbus_write_word(POWER_BELOW, 0x3b, fan_speed_min);
	__smbus_module_soft_reset();
	
	
	powers_sts[0].module = POWER_ABOVE;
	powers_sts[0].fan_speed = fan_speed_min;
	powers_sts[0].online = 0;
	powers_sts[1].module = POWER_BELOW;
	powers_sts[1].fan_speed = fan_speed_min;
	powers_sts[1].online = 0;

	power_dir = proc_mkdir(MODULE_NAME, NULL);
	if (!power_dir)
	{
		printk(KERN_ERR MODULE_NAME "fail to make proc dir!\n");
		retval = -ENOMEM;
		goto power_finish;
	}

	power_entry1 = create_proc_entry(POWER_INFO1, 0644, power_dir);
	if (!power_entry1)
	{
		printk(KERN_ERR MODULE_NAME "fail to create %s file!\n", POWER_INFO1);
		retval = -ENOMEM;
		goto err_create_file1;
	}

	power_entry2 = create_proc_entry(POWER_INFO2, 0644, power_dir);
	if (!power_entry1)
	{
		printk(KERN_ERR MODULE_NAME "fail to create %s file!\n", POWER_INFO2);
		retval = -ENOMEM;
		goto err_create_file2;
	}

	power_entry1->proc_fops = &power_module1_fops;
	power_entry2->proc_fops = &power_module2_fops;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27)
	/*
	 * because we need to use the psu_info_via_pic as a flag, so we need to create pic_i2c_psu_data here
	*/
	pic_i2c_psu_data = kzalloc ( sizeof ( struct pic_i2c_psu ), GFP_KERNEL );
	if ( pic_i2c_psu_data == NULL )
	{
		printk(KERN_ERR MODULE_NAME "fail to malloc memory for pic_i2c_psu_data!\n");
		goto pic_i2c_psu_data_malloc_err;
	}
	pic_i2c_psu_data->psu_info_via_pic = 0;

	/*
	 * The following two lines should be placed before i2c_add_drvier
	*/
	power_entry1->data = ( void * )pic_i2c_psu_data;
	power_entry2->data = ( void * )pic_i2c_psu_data;

	retval = i2c_add_driver ( &pic_i2c_driver );
	if ( retval )
	{
		printk ( KERN_ERR MODULE_NAME "register pic_i2c_driver failed.\n");
		goto i2c_add_driver_err;
	}
	
	
	goto power_finish;

i2c_add_driver_err:
	kfree ( pic_i2c_psu_data );
#endif	
pic_i2c_psu_data_malloc_err:
	remove_proc_entry(POWER_INFO2, power_dir);
err_create_file2:
	remove_proc_entry(POWER_INFO1, power_dir);
err_create_file1:
	remove_proc_entry(MODULE_NAME, NULL);

power_finish:
	nct6106_exit();
	
	return 0;
}

static void __exit smbus_power_exit(void)
{
	struct pic_i2c_psu *pic_i2c_psu_data;

#if LINUX_VERSION_CODE >= KERNEL_VERSION ( 2, 6, 27 )	
	pic_i2c_psu_data = ( struct pic_i2c_psu * )( power_entry1->data );
	
	i2c_del_driver ( &pic_i2c_driver );

	kfree ( pic_i2c_psu_data );
#endif	
	remove_proc_entry(POWER_INFO1, power_dir);
	remove_proc_entry(POWER_INFO2, power_dir);
	remove_proc_entry(MODULE_NAME, NULL);
	printk(KERN_INFO "SMBus Power Module Exit!\n");
}

MODULE_LICENSE("GPL");
module_init(smbus_power_init);
module_exit(smbus_power_exit);
MODULE_VERSION(VERSION_STRING);

