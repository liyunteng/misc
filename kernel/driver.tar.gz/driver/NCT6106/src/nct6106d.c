/*
    nct6106 - Driver for the hardware monitoring functionality of
                the NUVOTOM nct6106 Super-I/O chip

    Copyright (C) 2010~ Sheng-Yuan Huang (Nuvoton) (PS00)

    This driver supports the nct6106.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


    Supports the following chips:

    Chip        #vin    #fan    #temp      chip IDs       man ID
    nct6106      9      3        20         0xC45X
*/

#include <linux/module.h>
#include <linux/init.h>
#include <linux/slab.h>
#include <linux/jiffies.h>
#include <linux/platform_device.h>
#include <linux/hwmon.h>
#include <linux/hwmon-sysfs.h>
#include <linux/hwmon-vid.h>
#include <linux/err.h>
#include <linux/mutex.h>
#include <asm/io.h>
#include "lm75.h"

enum kinds { nct6106};

/* used to set data->name = nct6106_device_names[data->sio_kind] */
static const char * nct6106_device_names[] = {
	"nct6106"
};

static unsigned short force_id;
module_param(force_id, ushort, 0);
MODULE_PARM_DESC(force_id, "Override the detected device ID");


#define DRVNAME "nct6106"

/*
 * Super-I/O constants and functions
 */

#define NCT6106_LD_HWM	0x0b
//#define W83667HG_LD_VID 	0x0d

#define SIO_REG_LDSEL		0x07	/* Logical device select */
#define SIO_REG_DEVID		0x20	/* Device ID (2 bytes) */
//#define SIO_REG_EN_VRM10	0x2C	/* GPIO3, GPIO4 selection */
#define SIO_REG_ENABLE		0x30	/* Logical device enable */
#define SIO_REG_ADDR			0x60	/* Logical device address (2 bytes) */
//#define SIO_REG_VID_CTRL	0xF0	/* VID control */
//#define SIO_REG_VID_DATA	0xE9	/* VID data */


#define SIO_NCT6106_ID		0xC450
//#define SIO_NCT6106_ID_2	0x1060
#define SIO_ID_MASK			0xFFF0

static inline void
superio_outb(int ioreg, int reg, int val)
{
	outb(reg, ioreg);
	outb(val, ioreg + 1);
}

static inline int
superio_inb(int ioreg, int reg)
{
	outb(reg, ioreg);
	return inb(ioreg + 1);
}

static inline void
superio_select(int ioreg, int ld)
{
	outb(SIO_REG_LDSEL, ioreg);
	outb(ld, ioreg + 1);
}

static inline void
superio_enter(int ioreg)
{
	outb(0x87, ioreg);
	outb(0x87, ioreg);
}

static inline void
superio_exit(int ioreg)
{
	outb(0x02, ioreg);
	outb(0x02, ioreg + 1);
}

/*
 * ISA constants
 */

#define IOREGION_ALIGNMENT	~7
#define IOREGION_OFFSET		5 
#define IOREGION_LENGTH		2
//#define PAGE_REG_OFFSET		0
#define ADDR_REG_OFFSET		0
#define DATA_REG_OFFSET		1


//#define NCT6106_REG_CONFIG		0x40 //(Not Support)
#define NCT6106_REG_BANK			0x4E

/* For nct6106, fan is RPM format */
static const u16 NCT6106_REG_FAN[] = { 0x30, 0x32, 0x34}; 
static const u16 NCT6106_REG_FAN_MIN[] = { 0xE0, 0xE2, 0xE4};
//static const u16 NCT6106_REG_FAN_CONFIG[] = { 0x1C0, 0x1C1, 0x1C2, 0x1C3, 0x1C4, 0x1C5, 0x1C6, 0x1C7}; //Not Support in NCT6106

/* The NCT6106 registers for nr=13 is not continuous */
#define NCT6106_REG_IN_MAX(nr)	((nr < 6) ? (0x90 + (nr) * 2) : \
					 (0x92 + (nr) * 2))
#define NCT6106_REG_IN_MIN(nr)	((nr < 6) ? (0x91 + (nr) * 2) : \
					 (0x93 + (nr) * 2))
#define NCT6106_REG_IN(nr)		((nr < 6) ? (0x0  + (nr)) : \
					 (0x1  + (nr)))	// For NCT6106, 6 internal voltage(CPUVCORE...), 3 external voltage(VIN0,VIN1,VIN2).

//static const u16 NCT6106_REG_IN_CONFIG[] = { 0x1A0, 0x1A1}; //(Not Support)

/* Following temperature of NCT6106 has no hysteresis and over temperature,
   I deal with it specially. Notice that, some of them just have low-byte, 
   others have high/low bytes */
   //PCH_CHIP, PCH_CPU, PCH_MCH, PCH_DIM0~PCH_DIM3,
   //PCH_TSI0~7,
   //BYTE_TEMP,
   //PECI_TEMP, SYSTIN, CPUTIN, AUXTIN
static const u16 NCT6106_REG_TEMP2[] =  {0x51, 0x52, 0x54, 0x55, 0x56, 0x57, 0x58,
																	 0x59, 0x5B, 0x5D, 0x5F, 0x61, 0x63, 0x65, 0x67,
																	 0x69, 
																	 0x6B, 0x30C, 0x30D, 0x30E};


/* ???? 
I treat the shutdown temperature limit as critical temperature.

static const u16 NCT6106_REG_TEMP[] = { 0x10 };
static const u16 NCT6106_REG_TEMP_HYST[] = { 0x164, 0x166, 0x168, 0x16A, 0x16C, 0x16E, 0x170, 0x172, 0x174, 0x176 }; 
static const u16 NCT6106_REG_TEMP_OVER[] = { 0x178, 0x17A, 0x17C, 0x17E, 0x180, 0x182, 0x184, 0x186, 0x188, 0x18A };
//static const u16 NCT6106_REG_TEMP_CONFIG[] = { 0x150, 0x151, 0x152, 0x153, 0x154, 0x155, 0x156, 0x157, 0x158, 0x159 }; //Not Support in NCT6106
*/




/* Fan clock dividers are spread over the following five registers */
/* nct6106 needs NOT divisor */



static const u16 NCT6106_REG_DIODE = { 0x318 };  /* sensors type. */
static const u16 NCT6106_REG_CURRENT_ENABLE = { 0x319 };  /* sensors type. */



static const u16 NCT6106_REG_ALARM[] = { 0x77, 0x78, 0x7B };


/* SmartFan registers */


/* FAN Duty Cycle, be used to control */
static const u16 NCT6106_REG_PWM[] = { 0x119, 0x129, 0x139};
//static const u16 NCT6106_REG_PWM_WRITE[] = { 0x109, 0x209, 0x309}; /* For some chips such as nct6775 and nct6776, Manual output regs for read and write are different. */


/* DC or PWM output fan configuration */
static const u8 NCT6106_REG_PWM_ENABLE[] = {
	0xF3,			/* SYS output mode*/
	0xF3,			/* CPU output mode*/
	0xF3,			/* AUX FAN output mode */
};

static const u8 NCT6106_PWM_ENABLE_SHIFT[] = { 0, 1, 2};


/* Advanced Fan control, some values are common for all fans */
/* Now we don't provide smart fan for this project */


	/*
	 * Conversions
	 */

	/* 1 is PWM mode, output in ms */
	/*
	static inline unsigned int step_time_from_reg(u8 reg, u8 mode)
	{
		return mode ? 100 * reg : 400 * reg;
	}

	static inline u8 step_time_to_reg(unsigned int msec, u8 mode)
	{
		return SENSORS_LIMIT((mode ? (msec + 50) / 100 :
							(msec + 200) / 400), 1, 255);
	}
	*/
	/* Should Not used in nct6106.
	static inline unsigned int
	fan_from_reg(u8 reg, unsigned int div)
	{
		if (reg == 0 || reg == 255)
			return 0;
		return 1350000U / (reg * div);
	}

	static inline unsigned int
	div_from_reg(u8 reg)
	{
		return 1 << reg;
	}
	*/

/* For some chip, it has 13-bit format of fan count without divisor */
static inline unsigned int
fan_from_reg_13bit(u16 reg)
{
	if (reg == 0)
		return 0;
	if ((reg & 0xff1f) == 0xff1f)
		return 0;
	reg = (reg & 0x1f) | ((reg & 0xff00)>>3);
	return 1350000U / reg;
}

static inline unsigned int
fan_to_reg_13bit(u16 val)
{
	if (val == 0)
		return 0xff1f;
	val = 1350000U / val;
	val = (val & 0x1f) | ((val << 3) & 0xff00);
	return val;
}

static inline int
temp1_from_reg(s8 reg)
{
	return reg * 1000;
}

static inline s8
temp1_to_reg(long temp, int min, int max)
{
	if (temp <= min)
		return min / 1000;
	if (temp >= max)
		return max / 1000;
	if (temp < 0)
		return (temp - 500) / 1000;
	return (temp + 500) / 1000;
}

//For 8-bit interger part.
//reg: integer part
static inline long temp_from_reg_int(s8 reg){
	return reg * 1000;
}

//For fraction (1 bit)
//reg: fraction part
static inline long temp_from_reg_fraction(u8 reg){
	return (reg>>7) * 500;
}

//For getting integer part and translate into 8 bits reg
//temp: temperature value(including fraction part)
static inline s8
temp_to_reg_int(long temp, long min, long max)
{
	if (temp <= min)
		return min / 1000;
	if (temp >= max)
		return max / 1000;
	
	if (temp < 0){
		if ((temp%1000) != 0){
			return (temp/1000 - 1);
		}
	}
	return temp / 1000;
}

//For getting decimal fraction part and translate into 1 bit reg
//temp: temperature value(including fraction part)
static inline u8
temp_to_reg_fraction(long temp, long min, long max){

	long intPart;
	long fracPart;

	intPart = (temp/1000)*1000;
	if (temp < 0){
		if ((temp%1000) != 0){
			intPart = (temp/1000 - 1) * 1000;
		}
	}
	fracPart = temp - intPart;
	return (fracPart/500)<<7;
}


/* For 6106, all voltage analog inputs have the same internal scaling */

static u8 scale_in[9] = { 8, 8, 16, 16, 8, 
								  8, 16, 16, 8};

static inline long in_from_reg(u8 reg, u8 nr)
{
	return reg * scale_in[nr];
}

static inline u8 in_to_reg(u32 val, u8 nr)
{
	return SENSORS_LIMIT(((val + (scale_in[nr] / 2)) / scale_in[nr]), 0, 255);
}

/*
 * Data structures and manipulation thereof
 */

struct nct6106_data {
	int addr;	/* IO base of hw monitor block */
	const char *name;

	struct device *hwmon_dev;
	struct mutex lock;

	struct mutex update_lock;
	char valid;		/* !=0 if following fields are valid */
	unsigned long last_updated;	/* In jiffies */

	/* Register values */
	u16 has_in;
	u8 in_num;		/* number of in inputs we have */
	u8 in[9];		/* Register value */
	u8 in_max[9];		/* Register value */
	u8 in_min[9];		/* Register value */
	u16 fan[3];		/* nct6106 has 3 fan in RPM */
	u16 fan_min[3]; /* nct6106 has has 3 fan_min in count, no fan_div */
	//u8 fan_div[4];
	u8 has_fan;		/* some fan inputs can be disabled */

	u32 has_temp;
	u8 temp_type[20]; 
	u16 temp[20]; 	/* Reg value */
	u16 temp_max[20];
	u16 temp_max_hyst[20];
	u32 alarms[1];  //Fro 6106, it has 18 bits for status

	u8 pwm_mode[3]; /* 0->DC variable voltage, 1->PWM variable duty cycle */
//	u8 fan_mode[3]; /* 1->manual
//			     2->thermal cruise (also called SmartFan I) */
	u8 pwm_num;		/* number of pwm */
	u8 pwm[3];

	u8 vid;
	u8 vrm;

};

struct nct6106_sio_data {
	int sioreg; 
	enum kinds kind;
};


//Only for is_word_size() function using, and just for shorten the code and easy to read.
#define DEFINE_WORD_SIZE_RANGE(PageWithZero,Min,Max)	\
if ((reg & 0xff00) == PageWithZero)							\
{ 																		\
	if ( (Min<=(reg&0x00FF)) && (reg&0x00FF) <= Max){ 	\
	   return true; 												\
	} 																	\
}

static inline int is_word_sized(u16 reg)
{
	//Temperature registers
	DEFINE_WORD_SIZE_RANGE(0x0, 0x52, 0x52);
	DEFINE_WORD_SIZE_RANGE(0x0, 0x59, 0x69);
	


	//SMIOVT Hysterisis


	//SMI OVT


	//Shutdown Temp (Critical)


	/* FAN. For nct6106, fan can be RPM format (2 bytes) */
	DEFINE_WORD_SIZE_RANGE(0x0, 0x30, 0x34);

	/* Fan low limit */
	DEFINE_WORD_SIZE_RANGE(0x0, 0xE0, 0xE4);

	return false;

}

static inline int is_word_sized_jmp_one(u16 reg){

	/*  In nct6106, there is no reg of this type*/
	
	return false;
}




/* Registers 0x50-0x5f are banked */
static inline void hm_set_bank(struct nct6106_data *data, u16 reg)
{
		outb_p(NCT6106_REG_BANK, data->addr + ADDR_REG_OFFSET);
		outb_p(reg >> 8, data->addr + DATA_REG_OFFSET);
}

/* Not strictly necessary, but play it safe for now */
static inline void hm_reset_bank(struct nct6106_data *data, u16 reg)
{
	if (reg & 0xff00) {
		outb_p(NCT6106_REG_BANK, data->addr + ADDR_REG_OFFSET);
		outb_p(0, data->addr + DATA_REG_OFFSET);
	}
}


//Assume that lower addr in HM is high-byte data.
static u16 nct6106_read_value(struct nct6106_data *data, u16 reg)
{
	int res, word_sized = is_word_sized(reg);
	int word_sized_jmp_one = is_word_sized_jmp_one(reg);
	
	mutex_lock(&data->lock);

	hm_set_bank(data, reg);
	outb_p(reg & 0xff, data->addr + ADDR_REG_OFFSET);
	res = inb_p(data->addr + DATA_REG_OFFSET);
	if (word_sized) {
		/* Some regs are not continuous */
		if (word_sized_jmp_one){
			outb_p((reg & 0xff) + 2,
			       data->addr + ADDR_REG_OFFSET);
			res = (res << 8) + inb_p(data->addr + DATA_REG_OFFSET);
		}
		else{
			outb_p((reg & 0xff) + 1,
			       data->addr + ADDR_REG_OFFSET);
			res = (res << 8) + inb_p(data->addr + DATA_REG_OFFSET);
		}
	}
	hm_reset_bank(data, reg);

	mutex_unlock(&data->lock);

	return res;
}

//Assume that lower addr in HM is high-byte data.
static int nct6106_write_value(struct nct6106_data *data, u16 reg, u16 value)
{
	int word_sized = is_word_sized(reg);
	int word_sized_jmp_one = is_word_sized_jmp_one(reg);

	mutex_lock(&data->lock);

	hm_set_bank(data, reg);
	outb_p(reg & 0xff, data->addr + ADDR_REG_OFFSET);
	if (word_sized) {
		if (word_sized_jmp_one){
			/* Some regs are not continuous  */
			outb_p(value >> 8, data->addr + DATA_REG_OFFSET);
			outb_p((reg & 0xff) + 2,
		       data->addr + ADDR_REG_OFFSET);
		}
		else{
			outb_p(value >> 8, data->addr + DATA_REG_OFFSET);
			outb_p((reg & 0xff) + 1,
		       data->addr + ADDR_REG_OFFSET);
		}
	}
	outb_p(value & 0xff, data->addr + DATA_REG_OFFSET);
	hm_reset_bank(data, reg);

	mutex_unlock(&data->lock);
	return 0;
}


/* This function assumes that the caller holds data->update_lock */
/*
static void nct6106_write_fan_div(struct nct6106_data *data, int nr)
{
	u8 reg;

	switch (nr) {
	case 0:
		reg = (nct6106_read_value(data, NCT6106_REG_FANDIV1) & 0x70)
		    | (data->fan_div[0] & 0x7);
		nct6106_write_value(data, NCT6106_REG_FANDIV1, reg);
		
		break;
	case 1:
		reg = (nct6106_read_value(data, NCT6106_REG_FANDIV1) & 0x7)
		    | (data->fan_div[1] & 0x70);
		nct6106_write_value(data, NCT6106_REG_FANDIV1, reg);
		break;
	case 2:
		reg = (nct6106_read_value(data, NCT6106_REG_FANDIV2) & 0x70)
		    | (data->fan_div[2] & 0x7);
		nct6106_write_value(data, NCT6106_REG_FANDIV2, reg);
		break;
	case 3:
		reg = (nct6106_read_value(data, NCT6106_REG_FANDIV2) & 0x7)
		    | (data->fan_div[3] & 0x70);
		nct6106_write_value(data, NCT6106_REG_FANDIV2, reg);
		break;
	}
}

static void nct6106_update_fan_div(struct nct6106_data *data)
{
	u8 i;

	i = nct6106_read_value(data, NCT6106_REG_FANDIV1);
	data->fan_div[0] = i & 0x7;
	data->fan_div[1] = (i & 0x70)>>4;
	i = nct6106_read_value(data, NCT6106_REG_FANDIV2);
	data->fan_div[2] = i & 0x7;
	
	if (data->has_fan & (1<<3)){
		data->fan_div[3] = (i & 0x70) >> 4;
	}


}
*/

static struct nct6106_data *nct6106_update_device(struct device *dev)
{
	struct nct6106_data *data = dev_get_drvdata(dev);

	int i;
	//struct nct6106_sio_data *sio_data = dev->platform_data;
	u8 reg;
	//u16 uValue;

	mutex_lock(&data->update_lock);

	if (time_after(jiffies, data->last_updated + HZ + HZ/2)
	 || !data->valid) {
		/* Fan clock dividers */
		//nct6106_update_fan_div(data);


		/* Measured voltages and limits */
		for (i = 0; i < data->in_num; i++) {

			data->in[i] = nct6106_read_value(data,
				      NCT6106_REG_IN(i));
			data->in_min[i] = nct6106_read_value(data,
					  NCT6106_REG_IN_MIN(i));
			data->in_max[i] = nct6106_read_value(data,
					  NCT6106_REG_IN_MAX(i));
		}


		/* Measured fan speeds and limits */
		for (i = 0; i < ARRAY_SIZE(data->fan); i++) {
			if (!(data->has_fan & (1 << i)))
				continue;

			data->fan[i] = nct6106_read_value(data,
				       NCT6106_REG_FAN[i]);
					

			/* nct6106 has the same fan min number as fan RPM */
			data->fan_min[i] = nct6106_read_value(data,
					   NCT6106_REG_FAN_MIN[i]);


		} //End of "for (i = 0; i < 5; i++) {"

		
		/* Fan output control */
	
		for (i = 0; i < ARRAY_SIZE(data->fan); i++) {
		
			// nct6106 only has PWM/DC Mode
			reg = nct6106_read_value(data, NCT6106_REG_PWM_ENABLE[i]);
			data->pwm_mode[i] = (reg & (1 << NCT6106_PWM_ENABLE_SHIFT[i]))?(0):(1); //1:PWM mode 0:DC mode
			data->pwm[i] = nct6106_read_value(data,
						NCT6106_REG_PWM[i]);
				

		} //End of "for (i = 0; i < 3; i++) {"



		/* Measured temperatures and limits */
		for (i = 0; i < ARRAY_SIZE(NCT6106_REG_TEMP2); i++) {
			data->temp[i] = nct6106_read_value(data,
					NCT6106_REG_TEMP2[i]);
		}

		/* ????
		for (i = 0; i < ARRAY_SIZE(data->temp); i++) {
			data->temp[i] = nct6106_read_value(data,
					NCT6106_REG_TEMP[i]);
		}
		
		for (i=0; i < ARRAY_SIZE(data->temp_max); i++){
			data->temp_max[i] = nct6106_read_value(data,
				    NCT6106_REG_TEMP_OVER[i]);
			data->temp_max_hyst[i] = nct6106_read_value(data,
					 NCT6106_REG_TEMP_HYST[i]);
	
		}
		*/

		/* nct6106 use real time status and SMI status
		   Use 'nr' number in show_alarm() to control the correct bit if needed. 
		   so I don't need to modify some sensors' bit position */
		data->alarms[0] = ((u32)nct6106_read_value(data,
					NCT6106_REG_ALARM[0])) |
			       (((u32)nct6106_read_value(data,
					NCT6106_REG_ALARM[1])) << 8) |
			       (((u32)nct6106_read_value(data,
					NCT6106_REG_ALARM[2])) << 16);


		data->last_updated = jiffies;
		data->valid = 1;
	}

	mutex_unlock(&data->update_lock);
	return data;
}

/*
 * Sysfs callback functions
 */
#define show_in_reg(reg) \
static ssize_t \
show_##reg(struct device *dev, struct device_attribute *attr, \
	   char *buf) \
{ \
	struct nct6106_data *data = nct6106_update_device(dev); \
	struct sensor_device_attribute *sensor_attr = to_sensor_dev_attr(attr); \
	int nr = sensor_attr->index; \
	return sprintf(buf, "%ld\n", in_from_reg(data->reg[nr], nr)); \
}
show_in_reg(in)
show_in_reg(in_min)
show_in_reg(in_max)

#define store_in_reg(REG, reg) \
static ssize_t \
store_in_##reg (struct device *dev, struct device_attribute *attr, \
			const char *buf, size_t count) \
{ \
	struct nct6106_data *data = dev_get_drvdata(dev); \
	struct sensor_device_attribute *sensor_attr = to_sensor_dev_attr(attr); \
	int nr = sensor_attr->index; \
	u32 val = simple_strtoul(buf, NULL, 10); \
 \
	mutex_lock(&data->update_lock); \
	data->in_##reg[nr] = in_to_reg(val, nr); \
	nct6106_write_value(data, NCT6106_REG_IN_##REG(nr), \
			      data->in_##reg[nr]); \
	mutex_unlock(&data->update_lock); \
	return count; \
}

store_in_reg(MIN, min)
store_in_reg(MAX, max)

static ssize_t show_alarm(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct nct6106_data *data = nct6106_update_device(dev);
	struct sensor_device_attribute *sensor_attr = to_sensor_dev_attr(attr);
	int nr = sensor_attr->index;

	return sprintf(buf, "%u\n", (data->alarms[nr/32] >> ((nr>=32)?(nr-32):nr) ) & 0x01);
	
}

static struct sensor_device_attribute sda_in_input[] = {
	SENSOR_ATTR(in0_input, S_IRUGO, show_in, NULL, 0),
	SENSOR_ATTR(in1_input, S_IRUGO, show_in, NULL, 1),
	SENSOR_ATTR(in2_input, S_IRUGO, show_in, NULL, 2),
	SENSOR_ATTR(in3_input, S_IRUGO, show_in, NULL, 3),
	SENSOR_ATTR(in4_input, S_IRUGO, show_in, NULL, 4),
	SENSOR_ATTR(in5_input, S_IRUGO, show_in, NULL, 5),
	SENSOR_ATTR(in6_input, S_IRUGO, show_in, NULL, 6),
	SENSOR_ATTR(in7_input, S_IRUGO, show_in, NULL, 7),
	SENSOR_ATTR(in8_input, S_IRUGO, show_in, NULL, 8),
};

static struct sensor_device_attribute sda_in_alarm[] = {
	SENSOR_ATTR(in0_alarm, S_IRUGO, show_alarm, NULL, 0),
	SENSOR_ATTR(in1_alarm, S_IRUGO, show_alarm, NULL, 1),
	SENSOR_ATTR(in2_alarm, S_IRUGO, show_alarm, NULL, 2),
	SENSOR_ATTR(in3_alarm, S_IRUGO, show_alarm, NULL, 3),
	SENSOR_ATTR(in4_alarm, S_IRUGO, show_alarm, NULL, 4),
	SENSOR_ATTR(in5_alarm, S_IRUGO, show_alarm, NULL, 5),
	SENSOR_ATTR(in6_alarm, S_IRUGO, show_alarm, NULL, 7),
	SENSOR_ATTR(in7_alarm, S_IRUGO, show_alarm, NULL, 8),
	SENSOR_ATTR(in8_alarm, S_IRUGO, show_alarm, NULL, 9),
	
};

static struct sensor_device_attribute sda_in_min[] = {
       SENSOR_ATTR(in0_min, S_IWUSR | S_IRUGO, show_in_min, store_in_min, 0),
       SENSOR_ATTR(in1_min, S_IWUSR | S_IRUGO, show_in_min, store_in_min, 1),
       SENSOR_ATTR(in2_min, S_IWUSR | S_IRUGO, show_in_min, store_in_min, 2),
       SENSOR_ATTR(in3_min, S_IWUSR | S_IRUGO, show_in_min, store_in_min, 3),
       SENSOR_ATTR(in4_min, S_IWUSR | S_IRUGO, show_in_min, store_in_min, 4),
       SENSOR_ATTR(in5_min, S_IWUSR | S_IRUGO, show_in_min, store_in_min, 5),
       SENSOR_ATTR(in6_min, S_IWUSR | S_IRUGO, show_in_min, store_in_min, 6),
       SENSOR_ATTR(in7_min, S_IWUSR | S_IRUGO, show_in_min, store_in_min, 7),
       SENSOR_ATTR(in8_min, S_IWUSR | S_IRUGO, show_in_min, store_in_min, 8),
    
};

static struct sensor_device_attribute sda_in_max[] = {
       SENSOR_ATTR(in0_max, S_IWUSR | S_IRUGO, show_in_max, store_in_max, 0),
       SENSOR_ATTR(in1_max, S_IWUSR | S_IRUGO, show_in_max, store_in_max, 1),
       SENSOR_ATTR(in2_max, S_IWUSR | S_IRUGO, show_in_max, store_in_max, 2),
       SENSOR_ATTR(in3_max, S_IWUSR | S_IRUGO, show_in_max, store_in_max, 3),
       SENSOR_ATTR(in4_max, S_IWUSR | S_IRUGO, show_in_max, store_in_max, 4),
       SENSOR_ATTR(in5_max, S_IWUSR | S_IRUGO, show_in_max, store_in_max, 5),
       SENSOR_ATTR(in6_max, S_IWUSR | S_IRUGO, show_in_max, store_in_max, 6),
       SENSOR_ATTR(in7_max, S_IWUSR | S_IRUGO, show_in_max, store_in_max, 7),
       SENSOR_ATTR(in8_max, S_IWUSR | S_IRUGO, show_in_max, store_in_max, 8),

};



#define show_fan_reg(reg) \
static ssize_t \
show_##reg(struct device *dev, struct device_attribute *attr, \
	   char *buf) \
{ \
	struct nct6106_data *data = nct6106_update_device(dev); \
	struct sensor_device_attribute *sensor_attr = to_sensor_dev_attr(attr); \
	int nr = sensor_attr->index; \
	return sprintf(buf, "%d\n", data->reg[nr]);	\
}

show_fan_reg(fan);


//For showing fan reg from count to RPM
#define show_fan_count_reg(reg) \
static ssize_t \
show_##reg(struct device *dev, struct device_attribute *attr, \
	   char *buf) \
{ \
	struct nct6106_data *data = nct6106_update_device(dev); \
	struct sensor_device_attribute *sensor_attr = to_sensor_dev_attr(attr); \
	int nr = sensor_attr->index; \
	return sprintf(buf, "%d\n", fan_from_reg_13bit(data->reg[nr]));	\
}


show_fan_count_reg(fan_min);

 
/*
static ssize_t
show_fan_div(struct device *dev, struct device_attribute *attr,
	     char *buf)
{
	struct nct6106_data *data = nct6106_update_device(dev);
	struct sensor_device_attribute *sensor_attr = to_sensor_dev_attr(attr);
	int nr = sensor_attr->index;
	return sprintf(buf, "%u\n", div_from_reg(data->fan_div[nr]));
}



static ssize_t
store_fan_min(struct device *dev, struct device_attribute *attr,
	      const char *buf, size_t count)
{
	struct nct6106_data *data = dev_get_drvdata(dev);
	struct sensor_device_attribute *sensor_attr = to_sensor_dev_attr(attr);
	int nr = sensor_attr->index;
	unsigned int val = simple_strtoul(buf, NULL, 10);
	unsigned int reg;
	u8 new_div;

	mutex_lock(&data->update_lock);
	if (!val) {
		// No min limit, alarm disabled
		data->fan_min[nr] = 255;
		new_div = data->fan_div[nr];  // No change 
		dev_info(dev, "fan%u low limit and alarm disabled\n", nr + 1);
	} else if ((reg = 1350000U / val) >= 128 * 255) {
		// Speed less than this value cannot possibly be represented,
		//   even with the highest divider (128) 
		data->fan_min[nr] = 254;
		new_div = 7; // 128 == (1 << 7) 
		dev_warn(dev, "fan%u low limit %u below minimum %u, set to "
			 "minimum\n", nr + 1, val, fan_from_reg(254, 128));
	} else if (!reg) {
		// Speed above this value cannot possibly be represented,
		//   even with the lowest divider (1) 
		data->fan_min[nr] = 1;
		new_div = 0; // 1 == (1 << 0) 
		dev_warn(dev, "fan%u low limit %u above maximum %u, set to "
			 "maximum\n", nr + 1, val, fan_from_reg(1, 1));
	} else {
		// Automatically pick the best divider, i.e. the one such
		//   that the min limit will correspond to a register value
		//   in the 96..192 range 
		new_div = 0;
		while (reg > 192 && new_div < 7) {
			reg >>= 1;
			new_div++;
		}
		data->fan_min[nr] = reg;
	}

	// Write both the fan clock divider (if it changed) and the new
	//   fan min (unconditionally) 
	if (new_div != data->fan_div[nr]) {
		// Preserve the fan speed reading 
		if (data->fan[nr] != 0xff) {
			if (new_div > data->fan_div[nr])
				data->fan[nr] >>= new_div - data->fan_div[nr];
			else if (data->fan[nr] & 0x80)
				data->fan[nr] = 0xff;
			else
				data->fan[nr] <<= data->fan_div[nr] - new_div;
		}

		dev_dbg(dev, "fan%u clock divider changed from %u to %u\n",
			nr + 1, div_from_reg(data->fan_div[nr]),
			div_from_reg(new_div));
		data->fan_div[nr] = new_div;
		nct6106_write_fan_div(data, nr);
		// Give the chip time to sample a new speed value 
		data->last_updated = jiffies;
	}
	nct6106_write_value(data, NCT6106_REG_FAN_MIN[nr],
			      data->fan_min[nr]);
	mutex_unlock(&data->update_lock);

	return count;
}
*/
/*
static ssize_t
store_fan_min(struct device *dev, struct device_attribute *attr,
	      const char *buf, size_t count)
{
	struct nct6106_data *data = dev_get_drvdata(dev);
	struct sensor_device_attribute *sensor_attr = to_sensor_dev_attr(attr);
	int nr = sensor_attr->index;
	unsigned int val = simple_strtoul(buf, NULL, 10);
	

	mutex_lock(&data->update_lock);

	data->fan_min[nr] = val & 0xFFFF;

	nct6106_write_value(data, NCT6106_REG_FAN_MIN[nr],
			      data->fan_min[nr]);
	mutex_unlock(&data->update_lock);

	return count;
}
*/


static ssize_t
store_fan_min(struct device *dev, struct device_attribute *attr,
	      const char *buf, size_t count)
{
	struct nct6106_data *data = dev_get_drvdata(dev);
	struct sensor_device_attribute *sensor_attr = to_sensor_dev_attr(attr);
	int nr = sensor_attr->index;
	unsigned int val = simple_strtoul(buf, NULL, 10);


	mutex_lock(&data->update_lock);

	data->fan_min[nr] = fan_to_reg_13bit(val) & 0xFFFF;

	nct6106_write_value(data, NCT6106_REG_FAN_MIN[nr],
			      data->fan_min[nr]);
	
	mutex_unlock(&data->update_lock);

	return count;
}


static struct sensor_device_attribute sda_fan_input[] = {
	SENSOR_ATTR(fan1_input, S_IRUGO, show_fan, NULL, 0),
	SENSOR_ATTR(fan2_input, S_IRUGO, show_fan, NULL, 1),
	SENSOR_ATTR(fan3_input, S_IRUGO, show_fan, NULL, 2),

};

static struct sensor_device_attribute sda_fan_alarm[] = {
	SENSOR_ATTR(fan1_alarm, S_IRUGO, show_alarm, NULL, 16),
	SENSOR_ATTR(fan2_alarm, S_IRUGO, show_alarm, NULL, 17),
	SENSOR_ATTR(fan3_alarm, S_IRUGO, show_alarm, NULL, 18),

};

static struct sensor_device_attribute sda_fan_min[] = {
	SENSOR_ATTR(fan1_min, S_IWUSR | S_IRUGO, show_fan_min,
		    store_fan_min, 0),
	SENSOR_ATTR(fan2_min, S_IWUSR | S_IRUGO, show_fan_min,
		    store_fan_min, 1),
	SENSOR_ATTR(fan3_min, S_IWUSR | S_IRUGO, show_fan_min,
		    store_fan_min, 2),
};

/*
static struct sensor_device_attribute sda_fan_div[] = {
	SENSOR_ATTR(fan1_div, S_IRUGO, show_fan_div, NULL, 0),
	SENSOR_ATTR(fan2_div, S_IRUGO, show_fan_div, NULL, 1),
	SENSOR_ATTR(fan3_div, S_IRUGO, show_fan_div, NULL, 2),
	SENSOR_ATTR(fan4_div, S_IRUGO, show_fan_div, NULL, 3),
//	SENSOR_ATTR(fan5_div, S_IRUGO, show_fan_div, NULL, 4),
};
*/

#define show_temp1_reg(reg) \
static ssize_t \
show_##reg(struct device *dev, struct device_attribute *attr, \
	   char *buf) \
{ \
	struct nct6106_data *data = nct6106_update_device(dev); \
	return sprintf(buf, "%d\n", temp1_from_reg(data->reg)); \
}




#define store_temp1_reg(REG, reg) \
static ssize_t \
store_temp1_##reg(struct device *dev, struct device_attribute *attr, \
		  const char *buf, size_t count) \
{ \
	struct nct6106_data *data = dev_get_drvdata(dev); \
	long val = simple_strtol(buf, NULL, 10); \
 \
	mutex_lock(&data->update_lock); \
	data->temp1_##reg = temp1_to_reg(val, -128000, 127000); \
	nct6106_write_value(data, NCT6106_REG_TEMP1_##REG, \
			      data->temp1_##reg); \
	mutex_unlock(&data->update_lock); \
	return count; \
}



#define show_temp_reg(reg) \
static ssize_t \
show_##reg(struct device *dev, struct device_attribute *attr, \
	   char *buf) \
{ \
	struct nct6106_data *data = nct6106_update_device(dev); \
	struct sensor_device_attribute *sensor_attr = to_sensor_dev_attr(attr); \
	int nr = sensor_attr->index; \
	return sprintf(buf, "%ld\n", \
		       temp_from_reg_int((data->reg[nr]>>8)&0xFF ) + \
		       temp_from_reg_fraction(data->reg[nr]%0xFF)); \
}

#define show_temp_reg_only_integer(reg) \
static ssize_t \
show_##reg##_integer(struct device *dev, struct device_attribute *attr, \
	   char *buf) \
{ \
	struct nct6106_data *data = nct6106_update_device(dev); \
	struct sensor_device_attribute *sensor_attr = to_sensor_dev_attr(attr); \
	int nr = sensor_attr->index; \
	return sprintf(buf, "%ld\n", \
		       temp_from_reg_int((data->reg[nr])&0xFF)); \
}

show_temp_reg(temp);
show_temp_reg_only_integer(temp); //For NCT6106, some temperature just have integer portion
show_temp_reg(temp_max);
show_temp_reg(temp_max_hyst);




#define store_temp_reg(REG, reg) \
static ssize_t \
store_##reg(struct device *dev, struct device_attribute *attr, \
	    const char *buf, size_t count) \
{ \
	struct nct6106_data *data = dev_get_drvdata(dev); \
	struct sensor_device_attribute *sensor_attr = to_sensor_dev_attr(attr); \
	int nr = sensor_attr->index; \
	long val = simple_strtol(buf, NULL, 10); \
 \
	mutex_lock(&data->update_lock); \
	data->reg[nr] = (((u16)(u8)temp_to_reg_int(val, -128000, 127000)) << 8) | \
						(temp_to_reg_fraction(val, -128000, 127000) & 0xFF); \
	nct6106_write_value(data, NCT6106_REG_TEMP_##REG[nr], \
			      data->reg[nr]); \
	mutex_unlock(&data->update_lock); \
	return count; \
}
//store_temp_reg(OVER, temp_max);
//store_temp_reg(HYST, temp_max_hyst);




static ssize_t
show_temp_type(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct nct6106_data *data = nct6106_update_device(dev);
	struct sensor_device_attribute *sensor_attr = to_sensor_dev_attr(attr);
	int nr = sensor_attr->index;
	return sprintf(buf, "%d\n", (int)data->temp_type[nr]);
}

#define SENSOR_ATTR_TEMP(index)		\
	SENSOR_ATTR(temp##index##_input, S_IRUGO, show_temp, NULL, index-1), \
	SENSOR_ATTR(temp##index##_max, S_IRUGO | S_IWUSR, show_temp_max, \
		    store_temp_max, index-1), \
	SENSOR_ATTR(temp##index##_max_hyst, S_IRUGO | S_IWUSR, show_temp_max_hyst, \
		    store_temp_max_hyst, index-1), \
	SENSOR_ATTR(temp##index##_alarm, S_IRUGO, show_alarm, NULL, index-1), \
	SENSOR_ATTR(temp##index##_type, S_IRUGO, show_temp_type, NULL, index-1)


//For NCT6106, most temperatures have no limit, hyst and alarm
#define SENSOR_ATTR_TEMP_ONLY_HAS_TEMP(index)		\
	SENSOR_ATTR(temp##index##_input, S_IRUGO, show_temp, NULL, index-1), \
	SENSOR_ATTR(temp##index##_type, S_IRUGO, show_temp_type, NULL, index-1)

//For NCT6106, some temperatures only have integer portion and have no limit, hyst and alarm
#define SENSOR_ATTR_TEMP_ONLY_HAS_INTEGER_TEMP(index)		\
	SENSOR_ATTR(temp##index##_input, S_IRUGO, show_temp_integer, NULL, index-1), \
	SENSOR_ATTR(temp##index##_type, S_IRUGO, show_temp_type, NULL, index-1)


static struct sensor_device_attribute sda_temp[] = {
	SENSOR_ATTR_TEMP_ONLY_HAS_INTEGER_TEMP(1),
	SENSOR_ATTR_TEMP_ONLY_HAS_TEMP(2),
	SENSOR_ATTR_TEMP_ONLY_HAS_INTEGER_TEMP(3),
	SENSOR_ATTR_TEMP_ONLY_HAS_INTEGER_TEMP(4),
	SENSOR_ATTR_TEMP_ONLY_HAS_INTEGER_TEMP(5),
	SENSOR_ATTR_TEMP_ONLY_HAS_INTEGER_TEMP(6),
	SENSOR_ATTR_TEMP_ONLY_HAS_INTEGER_TEMP(7),
	SENSOR_ATTR_TEMP_ONLY_HAS_TEMP(8),
	SENSOR_ATTR_TEMP_ONLY_HAS_TEMP(9),
	SENSOR_ATTR_TEMP_ONLY_HAS_TEMP(10),
	SENSOR_ATTR_TEMP_ONLY_HAS_TEMP(11),
	SENSOR_ATTR_TEMP_ONLY_HAS_TEMP(12),
	SENSOR_ATTR_TEMP_ONLY_HAS_TEMP(13),
	SENSOR_ATTR_TEMP_ONLY_HAS_TEMP(14),
	SENSOR_ATTR_TEMP_ONLY_HAS_TEMP(15),
	SENSOR_ATTR_TEMP_ONLY_HAS_TEMP(16),
	SENSOR_ATTR_TEMP_ONLY_HAS_INTEGER_TEMP(17),
	SENSOR_ATTR_TEMP_ONLY_HAS_INTEGER_TEMP(18),
	SENSOR_ATTR_TEMP_ONLY_HAS_INTEGER_TEMP(19),
	SENSOR_ATTR_TEMP_ONLY_HAS_INTEGER_TEMP(20),
};

//in lm-sensors spec, pwm's range is 0~255
#define show_pwm_reg(reg) \
static ssize_t show_##reg (struct device *dev, struct device_attribute *attr, \
				char *buf) \
{ \
	struct nct6106_data *data = nct6106_update_device(dev); \
	struct sensor_device_attribute *sensor_attr = to_sensor_dev_attr(attr); \
	int nr = sensor_attr->index; \
	return sprintf(buf, "%d\n", data->reg[nr]); \
}

show_pwm_reg(pwm_mode)
show_pwm_reg(pwm)






static struct sensor_device_attribute sda_pwm[] = {
	SENSOR_ATTR(pwm1, S_IRUGO, show_pwm, NULL, 0),
	SENSOR_ATTR(pwm2, S_IRUGO, show_pwm, NULL, 1),
	SENSOR_ATTR(pwm3, S_IRUGO, show_pwm, NULL, 2),

};

static struct sensor_device_attribute sda_pwm_mode[] = {
	SENSOR_ATTR(pwm1_mode, S_IRUGO, show_pwm_mode,
		    NULL, 0),
	SENSOR_ATTR(pwm2_mode, S_IRUGO, show_pwm_mode,
		    NULL, 1),
	SENSOR_ATTR(pwm3_mode, S_IRUGO, show_pwm_mode,
		    NULL, 2),
};




static ssize_t show_name(struct device *dev, struct device_attribute *attr,
			 char *buf)
{
	struct nct6106_data *data = dev_get_drvdata(dev);

	return sprintf(buf, "%s\n", data->name);
}
static DEVICE_ATTR(name, S_IRUGO, show_name, NULL);


static ssize_t
show_vid(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct nct6106_data *data = dev_get_drvdata(dev);
	return sprintf(buf, "%d\n", vid_from_reg(data->vid, data->vrm));
}
//static DEVICE_ATTR(cpu0_vid, S_IRUGO, show_vid, NULL);




/*
 * Driver and device management
 */

static void nct6106_device_remove_files(struct device *dev)
{
	/* some entries in the following arrays may not have been used in
	 * device_create_file(), but device_remove_file() will ignore them */
	int i;
	struct nct6106_data *data = dev_get_drvdata(dev);

	
	for (i = 0; i < ARRAY_SIZE(data->in); i++) {
		device_remove_file(dev, &sda_in_input[i].dev_attr);
		device_remove_file(dev, &sda_in_alarm[i].dev_attr);
		device_remove_file(dev, &sda_in_min[i].dev_attr);
		device_remove_file(dev, &sda_in_max[i].dev_attr);
	}
	for (i = 0; i < ARRAY_SIZE(data->fan); i++) {
		device_remove_file(dev, &sda_fan_input[i].dev_attr);
		device_remove_file(dev, &sda_fan_alarm[i].dev_attr);
		device_remove_file(dev, &sda_fan_min[i].dev_attr);

	}
	for (i = 0; i < ARRAY_SIZE(data->pwm); i++) {
		device_remove_file(dev, &sda_pwm[i].dev_attr);
		device_remove_file(dev, &sda_pwm_mode[i].dev_attr);
	}


	for (i = 0; i < ARRAY_SIZE(sda_temp); i++)
		device_remove_file(dev, &sda_temp[i].dev_attr);

	device_remove_file(dev, &dev_attr_name);
//	device_remove_file(dev, &dev_attr_cpu0_vid);


}

/* Get the monitoring functions started */
static inline void __devinit nct6106_init_device(struct nct6106_data *data)
{
	int i;
	u8 tmp;
//	u8 diode;
	u8 TDMode[3];

	/* Start monitoring if needed:
	   NCT6106 has no this setting 
	tmp = nct6106_read_value(data, NCT6106_REG_CONFIG);
	if (!(tmp & 0x80))
		nct6106_write_value(data, NCT6106_REG_CONFIG,
				      tmp | 0x80);
	*/			      


	/* Enable SMIOVT if needed:
		For nct6106, we don't enable SMI in this driver,
		becuase SMI singal is bound to be trigered if condition is true. 
	*/
	
	

	/* Enable VBAT monitoring if needed */
	tmp = nct6106_read_value(data, NCT6106_REG_DIODE) & 0xFF;
	nct6106_write_value(data, NCT6106_REG_DIODE, tmp | 0x1);


	/* Get thermal sensor types:  2:Current Mode 3:Termal diode 4:Thermistor 5:AMD-TSI 6:PECI*/

	tmp = nct6106_read_value(data, NCT6106_REG_DIODE) & 0xFF;
	for (i=0; i<3; i++){
		if ( (tmp>>(i+1)) & 0x1 ){
			TDMode[i] = 3;
		}
		else{
			TDMode[i] = 4;
		}
//		TDMode[i] = 0; //Unknow, assign 0 temporarily
	}

	tmp = nct6106_read_value(data, NCT6106_REG_CURRENT_ENABLE);
	for (i = 0; i < ARRAY_SIZE(data->temp); i++) { /* we use the size of data->temp for more easy to detect bug if it exists */
		if (i<=6){
			data->temp_type[i] = 1; //For PCH's temp data, give them a default type value.
		}
		else if ((7<= i) && (i <=15)) { //AMD-TSI
			data->temp_type[i] = 5;
		}
		else if ( i == 16 ){ //PECI
			data->temp_type[i] = 6;
		}
		else if ((17 <= i) && (i <=19)) {
			if ((tmp>>(i-17)) & 0x1){
				data->temp_type[i] = 2;
			}
			else{
				data->temp_type[i] = TDMode[i-17];
			}
		}
		else{
			data->temp_type[i] = 0; //Unknow, assign 0 temporarily
		}
	}
	
}


static int __devinit nct6106_probe(struct platform_device *pdev)
{
	struct device *dev = &pdev->dev;
	struct nct6106_sio_data *sio_data = dev->platform_data;
	struct nct6106_data *data;
	struct resource *res;
//	u8 fan3pin, fan4pin, fan5pin
//	u8 en_vrm10;
	int i, err = 0;

	printk(KERN_INFO DRVNAME ":module probe.\n");

	res = platform_get_resource(pdev, IORESOURCE_IO, 0);
	if (!request_region(res->start, IOREGION_LENGTH, DRVNAME)) {
		err = -EBUSY;
		dev_err(dev, "Failed to request region 0x%lx-0x%lx\n",
			(unsigned long)res->start,
			(unsigned long)res->start + IOREGION_LENGTH - 1);
		goto exit;
	}

	if (!(data = kzalloc(sizeof(struct nct6106_data), GFP_KERNEL))) {
		err = -ENOMEM;
		goto exit_release;
	}

	data->addr = res->start;
	mutex_init(&data->lock);
	mutex_init(&data->update_lock);
	data->name = nct6106_device_names[sio_data->kind];
	platform_set_drvdata(pdev, data);

	/* nct6106 have 9 voltage inputs */
	//data->in_num = (sio_data->kind == nct6106) ? 10 : 9;
	data->in_num = 9;
	
	/* nct6106 has 3 pwms */
	data->pwm_num = 3;

	/* Initialize the chip */
	nct6106_init_device(data);

	/* Read VID value */
	/*
	data->vrm = vid_which_vrm();
	superio_enter(sio_data->sioreg);
	
	superio_select(sio_data->sioreg, NCT6106_LD_HWM);
	if (superio_inb(sio_data->sioreg, SIO_REG_VID_CTRL) & 0x80) {
		if (sio_data->kind == nct6106) {
			en_vrm10 = superio_inb(sio_data->sioreg,
					       SIO_REG_EN_VRM10);
			if ((en_vrm10 & 0x08) && data->vrm == 90) {
				dev_warn(dev, "Setting VID input voltage to "
					 "TTL\n");
				superio_outb(sio_data->sioreg, SIO_REG_EN_VRM10,
					     en_vrm10 & ~0x08);
			} else if (!(en_vrm10 & 0x08) && data->vrm == 100) {
				dev_warn(dev, "Setting VID input voltage to "
					 "VRM10\n");
				superio_outb(sio_data->sioreg, SIO_REG_EN_VRM10,
					     en_vrm10 | 0x08);
			}
		}

			data->vid = superio_inb(sio_data->sioreg, SIO_REG_VID_DATA);
			if (sio_data->kind == nct6106) // 6 VID pins only 
				data->vid &= 0x3f;

			err = device_create_file(dev, &dev_attr_cpu0_vid);
			if (err)
				goto exit_release;
		} else {
			dev_info(dev, "VID pins in output mode, CPU VID not "
				 "available\n");
		}
	}

	*/

	/* Multi-Function Pins */
	/* In nct6106, multi-function pin is NOT controlled by BIOS/SW,
	   so we need not to detect it.
	   Just detect Enable bits of sensors later to know if OEM want to 
	   use its function.*/
		
	superio_exit(sio_data->sioreg);


	/* Some sensors can be disabled, we check it for fan */
	data->has_fan = 0x7;
	/*
	for (i=0; i<ARRAY_SIZE(data->fan); i++){
		if (0x80 & nct6106_read_value(data, NCT6106_REG_FAN_CONFIG[i])){
			data->has_fan |= (1 << i);
		}	
	}
	*/
	/* For NCT6106, switches do not support(by Spec v1.0) */
	


	/* For NCT6106, switches do not support(by Spec v1.0) */
   data->has_in = 0x1FF;
	/*
	data->has_in = nct6106_read_value(data, NCT6106_REG_IN_CONFIG[0]) & 0xFF;
	data->has_in |= (nct6106_read_value(data, NCT6106_REG_IN_CONFIG[1]) & 0xFF) << 8;
	*/
	/* bit 5 is reserved bit, and I want data->in[13] and bit-13 of data->has_in to 
	   be 3VSB instead of empty field. 
	if (data->has_in & 0x4000){
		data->has_in = (data->has_in & 0x1FFF) | 0x2000;
	}
	else{
		data->has_in = data->has_in & 0x1FFF;
	}
   */

	/* For NCT6106, switches do not support(by Spec v1.0) */
	data->has_temp = 0xFFFFFFFF;
	/*
	data->has_temp = 0; 
	for (i=0; i<ARRAY_SIZE(data->temp); i++){
		if (0x80 & nct6106_read_value(data, NCT6106_REG_TEMP_CONFIG[i])){
			data->has_temp |= (1 << i);
		}	
	} 
	*/


	/* divisor */


	/* Register sysfs hooks */

	
	for (i = 0; i < ARRAY_SIZE(data->in); i++){
		if (data->has_in & (1 << i)) {
			if ((err = device_create_file(dev, &sda_in_input[i].dev_attr))
				|| (err = device_create_file(dev,
					&sda_in_alarm[i].dev_attr))
				|| (err = device_create_file(dev,
					&sda_in_min[i].dev_attr))
				|| (err = device_create_file(dev,
					&sda_in_max[i].dev_attr))){
				goto exit_remove;
			}
		}
	}

	for (i = 0; i < ARRAY_SIZE(data->fan); i++) {
		if (data->has_fan & (1 << i)) {
			
			if ((err = device_create_file(dev,
					&sda_fan_input[i].dev_attr))
				|| (err = device_create_file(dev,
					&sda_fan_alarm[i].dev_attr))
				|| (err = device_create_file(dev,
					&sda_fan_min[i].dev_attr))
				)
				goto exit_remove;
			
			if(i < data->pwm_num &&
				((err = device_create_file(dev,
					&sda_pwm[i].dev_attr))
				|| (err = device_create_file(dev,
					&sda_pwm_mode[i].dev_attr))
				
				))
				goto exit_remove;
		} //End of "if (data->has_fan & (1 << i)) {"
	}

	for (i = 0; i < ARRAY_SIZE(sda_temp); i++){
//By NCT6106 Spec 1.0, all temp are on. 
//Notice that, for NCT6106, each temp has different number of attributes(temp, hyst, max...)
//		if (data->has_temp & (1 << (i/5))){
			if ((err = device_create_file(dev, &sda_temp[i].dev_attr))){
				goto exit_remove;
			}
//		}
	}

	err = device_create_file(dev, &dev_attr_name);
	if (err)
		goto exit_remove;

	data->hwmon_dev = hwmon_device_register(dev);
	if (IS_ERR(data->hwmon_dev)) {
		err = PTR_ERR(data->hwmon_dev);
		goto exit_remove;
	}

	return 0;

exit_remove:
	nct6106_device_remove_files(dev);
	kfree(data);
	platform_set_drvdata(pdev, NULL);
exit_release:
	release_region(res->start, IOREGION_LENGTH);
exit:
	return err;
}

static int __devexit nct6106_remove(struct platform_device *pdev)
{
	struct nct6106_data *data = platform_get_drvdata(pdev);

	hwmon_device_unregister(data->hwmon_dev);
	nct6106_device_remove_files(&pdev->dev);
	release_region(data->addr, IOREGION_LENGTH);
	platform_set_drvdata(pdev, NULL);
	kfree(data);

	return 0;
}

static struct platform_driver nct6106_driver = {
	.driver = {
		.owner	= THIS_MODULE,
		.name	= DRVNAME,
	},
	.probe		= nct6106_probe,
	.remove		= __devexit_p(nct6106_remove),
};

/* nct6106_find() looks for nct6106 in the Super-I/O config space */
static int __init nct6106_find(int sioaddr, unsigned short *addr,
				 struct nct6106_sio_data *sio_data)
{

	static const char __initdata sio_name_NCT6106[] = "NCT6106";

	u16 val;
	const char *sio_name;

	superio_enter(sioaddr);

	if (force_id)
		val = force_id;
	else
		val = (superio_inb(sioaddr, SIO_REG_DEVID) << 8)
		    | superio_inb(sioaddr, SIO_REG_DEVID + 1);
	switch (val & SIO_ID_MASK) {

	case SIO_NCT6106_ID:
		sio_data->kind = nct6106;
		sio_name = sio_name_NCT6106;
		break;
	default:
		if (val != 0xffff){
			printk(KERN_INFO DRVNAME ": unsupported chip ID: 0x%04x\n",
				 val);
		}
		else{
			printk(KERN_INFO DRVNAME ": chip ID is not found: 0x%04x\n",
				 val);
		}
		superio_exit(sioaddr);
		return -ENODEV;
	}

	/* We have a known chip, find the HWM I/O address */
	superio_select(sioaddr, NCT6106_LD_HWM);
	val = (superio_inb(sioaddr, SIO_REG_ADDR) << 8)
	    | superio_inb(sioaddr, SIO_REG_ADDR + 1);
	*addr = val & IOREGION_ALIGNMENT;
	if (*addr == 0) {
		printk(KERN_ERR DRVNAME ": Refusing to enable a Super-I/O "
		       "device with a base I/O port 0.\n");
		superio_exit(sioaddr);
		return -ENODEV;
	}

	/* Activate logical device if needed */
	val = superio_inb(sioaddr, SIO_REG_ENABLE);
	if (!(val & 0x01)) {
		printk(KERN_WARNING DRVNAME ": Forcibly enabling Super-I/O. "
		       "Sensor is probably unusable.\n");
		superio_outb(sioaddr, SIO_REG_ENABLE, val | 0x01);
	}

	superio_exit(sioaddr);
	printk(KERN_INFO DRVNAME ": Found %s chip at %#x\n", sio_name, *addr);
	sio_data->sioreg = sioaddr;

	return 0;
}

/* when Super-I/O functions move to a separate file, the Super-I/O
 * bus will manage the lifetime of the device and this module will only keep
 * track of the nct6106 driver. But since we platform_device_alloc(), we
 * must keep track of the device */
static struct platform_device *pdev;

static int __init sensors_nct6106_init(void)
{
	int err;
	unsigned short address;
	struct resource res;
	struct nct6106_sio_data sio_data;

	/* initialize sio_data->kind and sio_data->sioreg.
	 *
	 * when Super-I/O functions move to a separate file, the Super-I/O
	 * driver will probe 0x2e and 0x4e and auto-detect the presence of a
	 * nct6106 hardware monitor, and call probe() */
	if (nct6106_find(0x2e, &address, &sio_data) &&
	    nct6106_find(0x4e, &address, &sio_data))
		return -ENODEV;

	err = platform_driver_register(&nct6106_driver);
	if (err)
		goto exit;

	if (!(pdev = platform_device_alloc(DRVNAME, address))) {
		err = -ENOMEM;
		printk(KERN_ERR DRVNAME ": Device allocation failed\n");
		goto exit_unregister;
	}

	err = platform_device_add_data(pdev, &sio_data,
				       sizeof(struct nct6106_sio_data));
	if (err) {
		printk(KERN_ERR DRVNAME ": Platform data allocation failed\n");
		goto exit_device_put;
	}

	memset(&res, 0, sizeof(res));
	res.name = DRVNAME;
	res.start = address + IOREGION_OFFSET;
	res.end = address + IOREGION_OFFSET + IOREGION_LENGTH - 1;
	res.flags = IORESOURCE_IO;
	err = platform_device_add_resources(pdev, &res, 1);
	if (err) {
		printk(KERN_ERR DRVNAME ": Device resource addition failed "
		       "(%d)\n", err);
		goto exit_device_put;
	}

	/* platform_device_add calls probe() */
	err = platform_device_add(pdev);
	if (err) {
		printk(KERN_ERR DRVNAME ": Device addition failed (%d)\n",
		       err);
		goto exit_device_put;
	}

	return 0;

exit_device_put:
	platform_device_put(pdev);
exit_unregister:
	platform_driver_unregister(&nct6106_driver);
exit:
	return err;
}

static void __exit sensors_nct6106_exit(void)
{
	platform_device_unregister(pdev);
	platform_driver_unregister(&nct6106_driver);
}

MODULE_AUTHOR("SYHuang <syhuang3@nuvoton.com>");
MODULE_DESCRIPTION("nct6106 driver");
MODULE_LICENSE("GPL");

module_init(sensors_nct6106_init);
module_exit(sensors_nct6106_exit);
